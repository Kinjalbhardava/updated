<?php
include("conn.php");

// Search and sort
$search = isset($_GET['search']) ? $_GET['search'] : '';
$sort_order = 'ASC';
$order_by = 'id';
$items_per_page = 5;

$page = max((int) ($_GET['page'] ?? 1), 1);
$offset = ($page - 1) * $items_per_page;

if (isset($_GET['order_by']) && in_array($_GET['order_by'], ['id', 'c_name', 's_name', 'country_name'])) {
    $order_by = $_GET['order_by'];
}

if (isset($_GET['sort_order']) && in_array($_GET['sort_order'], ['ASC', 'DESC'])) {
    $sort_order = $_GET['sort_order'];
}

// Toggle sorting order for the next click

$next_sort_order = $sort_order === 'ASC' ? 'DESC' : 'ASC';
$icon = $sort_order === 'ASC' ? 'fa-sort-up' : 'fa-sort-down';


// Count total records

$totalQuery = "SELECT COUNT(*) FROM city 
                JOIN states ON city.state_id = states.id 
                JOIN country ON states.country_id = country.id" .
    ($search ? " WHERE city.c_name LIKE ?" : "");

$totalStmt = $con->prepare($totalQuery);
if ($search) {
    $searchParam = "%$search%";
    $totalStmt->bind_param('s', $searchParam);
}
$totalStmt->execute();
$total = $totalStmt->get_result()->fetch_row()[0];
$total_pages = ceil($total / $items_per_page);

// Fetch the records
$query = "SELECT city.*, country.name AS country_name, states.s_name AS states_name 
          FROM city 
          JOIN states ON city.state_id = states.id 
          JOIN country ON states.country_id = country.id" .
    ($search ? " WHERE city.c_name LIKE ? " : "") .
    " ORDER BY $order_by $sort_order LIMIT ?, ?";

$stmt = $con->prepare($query);
if ($search) {
    $stmt->bind_param('sii', $searchParam, $offset, $items_per_page);
} else {
    $stmt->bind_param('ii', $offset, $items_per_page);
}

$stmt->execute();
$res = $stmt->get_result();

// CSV Export Logic
if (isset($_GET['export']) && $_GET['export'] == 'csv') {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="city_list.csv"');

    $output = fopen('php://output', 'w');
    fputcsv($output, ['City Id', 'City Name', 'State Name', 'Country Name']);

    $export_query = "SELECT city.*, country.name AS country_name, states.s_name AS states_name 
          FROM city 
          JOIN states ON city.state_id = states.id 
          JOIN country ON states.country_id = country.id" .
        ($search ? " WHERE city.c_name LIKE ? " : "") .
        " ORDER BY $order_by $sort_order";

    $export_stmt = $con->prepare($export_query);
    if ($search) {
        $export_stmt->bind_param('s', $searchParam);
    }
    $export_stmt->execute();
    $export_result = $export_stmt->get_result();

    if ($export_result->num_rows > 0) {
        while ($row = $export_result->fetch_assoc()) {
            fputcsv($output, [$row['id'], $row['c_name'], $row['states_name'], $row['country_name']]);

        }
    }

    fclose($output);
    $export_stmt->close();
    exit;

}

// EXCEL DATA EXPORTING

if (isset($_GET['export']) && $_GET['export'] == 'excel') {
    $file_name = "cities_" . ".xls";
    $field = array('Id', 'City name', 'States name', 'Country_name');
    $excel_data = implode("\t", $field) . "\n";

    $export_query = "SELECT city.*, country.name AS country_name, states.s_name AS states_name 
                     FROM city 
                     JOIN states ON city.state_id = states.id 
                     JOIN country ON states.country_id = country.id" .
                     ($search ? " WHERE city.c_name LIKE ? " : "") .
                     " ORDER BY $order_by $sort_order";

    $export_stmt = $con->prepare($export_query);
    if ($search) {
        $export_stmt->bind_param('s', $searchParam);
    }
    $export_stmt->execute();
    $result = $export_stmt->get_result();

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $linedata = array($row['id'], $row['c_name'], $row['states_name'], $row['country_name']);
            $excel_data .= implode("\t", $linedata) . "\n";
        }
    } else {
        $excel_data .= "No records found...\n";
    }

    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition: attachment; filename=\"$file_name\"");

    echo $excel_data;
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }

        #sidebar {
            min-height: 100vh;
        }

        .table-hover tbody tr:hover {
            background-color: #e9ecef;
        }

        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }

        .row1 h2 {
            margin-bottom: 25px;
        }

        .fas {
            margin-right: 20px;
        }

        .nav-link {
            color: rgb(41, 41, 182);
            margin-bottom: 10px;
        }

        a {
            text-decoration: none;
            color: black;
        }

        .navmob {
            display: none;
        }

        @media screen and (max-width:767px) {
            .navmob {
                display: block;
            }

            .slidebar {
                display: none;
            }

            .colnone {
                display: none;
            }

            .btnadd {
                width: 90%;
                height: 70%;
                font-size: 14px;

            }
        }
    </style>
</head>

<body>
    <div class="container-fluid">

        <!-- mobile view -->

        <nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top navmob">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">Admin Panel</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                    aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link active" href="index.php"><i class="fas fa-tachometer-alt"></i>
                                Dashboard</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="country.php"><i class="fas fa-flag"></i> Country</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="state.php"><i class="fas fa-map-marker-alt"></i> State</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="city.php"><i class="fas fa-building"></i> City</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

        <!-- desktop view -->

        <div class="row">
            <div class="col-md-2 bg-light text-dark p-4 slidebar" id="sidebar">
                <h2 class="ps-4 pb-3">Admin</h2>
                <ul class="nav flex-column">
                    <li class="nav-item"><a class="nav-link active" href="index.php"><i
                                class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="country.php"><i class="fas fa-flag"></i> Country</a>
                    </li>
                    <li class="nav-item"><a class="nav-link" href="state.php"><i class="fas fa-map-marker-alt"></i>
                            State</a></li>
                    <li class="nav-item"><a class="nav-link" href="city.php"><i class="fas fa-building"></i> City</a>
                    </li>
                </ul>
            </div>
            <div class="col-md-10 p-4" id="main-content">
                <div class="row mb-4">
                    <div class="col">
                        <h3><i class="fas fa-globe"></i> Cities Listing</h3>
                    </div>
                </div>

                <form method="get" class="row mb-3 ">
                   
                        <div class="col col-lg-3 flex-end">
                            <input class="form-control" type="search" name="search"
                                value="<?php echo htmlspecialchars($search); ?>" placeholder="Search"
                                aria-label="Search">
                        </div>
                        <div class="col-auto">
                            <button type="submit" class="btn btn-success mb-3">Search</button>
                        </div>
                        <div class="col col-lg-4 colnone"></div>
                        <div class="col">
                            <a href="newcityadd.php" class="btn btn-primary mb-3"><i class="fas fa-plus me-2"></i>
                                Add
                                City</a>
                        </div>
                        <div class="col">
                            <a href="?export=csv&search=<?php echo urlencode($search); ?>&order_by=<?php echo $order_by; ?>&sort_order=<?php echo $sort_order; ?>"
                                class="btn btn-info mb-3"><i class="fas fa-file-csv me-2"></i> Export CSV</a>
                            <a href="?export=excel&search=<?php echo urlencode($search); ?>&order_by=<?php echo $order_by; ?>&sort_order=<?php echo $sort_order; ?>"
                                class="btn btn-info mb-3"><i class="fas fa-file-csv me-2"></i> Export Excel</a>
                        </div>
                </form>

                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th><a
                                    href="?page=<?php echo $page; ?>&search=<?php echo urlencode($search); ?>&order_by=id&sort_order=<?php echo $next_sort_order; ?>">City
                                    ID <i class="fas <?php echo ($order_by == 'id') ? $icon : 'fa-sort'; ?>"></i></a>
                            </th>
                            <th>
                                <a
                                    href="?page=<?php echo $page; ?>&search=<?php echo urlencode($search); ?>&order_by=c_name&sort_order=<?php echo $next_sort_order; ?>">
                                    City Name
                                    <i class="fas <?php echo ($order_by === 'c_name') ? $icon : 'fa-sort'; ?>"></i>
                                </a>
                            </th>
                            <th>
                                <a
                                    href="?page=<?php echo $page; ?>&search=<?php echo urlencode($search); ?>&order_by=s_name&sort_order=<?php echo $next_sort_order; ?>">
                                    State Name
                                    <i class="fas <?php echo ($order_by === 's_name') ? $icon : 'fa-sort'; ?>"></i>
                                </a>
                            </th>
                            <th>
                                <a
                                    href="?page=<?php echo $page; ?>&search=<?php echo urlencode($search); ?>&order_by=country_name&sort_order=<?php echo $next_sort_order; ?>">
                                    Country Name
                                    <i
                                        class="fas <?php echo ($order_by === 'country_name') ? $icon : 'fa-sort'; ?>"></i>
                                </a>
                            </th>
                            <th>Edit City</th>
                            <th>Delete City</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $statusMessages = [
                            'success' => "Your record has been inserted successfully!",
                            'delete' => "Your record was deleted successfully!",
                            'update' => "Data updated successfully!",
                        ];

                        if (isset($_GET['status']) && array_key_exists($_GET['status'], $statusMessages)) {
                            echo "<div class='alert alert-" . ($_GET['status'] === 'delete' ? 'danger' : 'success') . " alert-dismissible fade show' role='alert'>"
                                . $statusMessages[$_GET['status']]
                                . "<button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>"
                                . "</div>";
                        }

                        if ($res->num_rows > 0) {
                            while ($row = $res->fetch_assoc()) {
                                echo "<tr>";
                                echo "<td>" . htmlspecialchars($row['id']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['c_name']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['states_name']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['country_name']) . "</td>";
                                echo "<td><a href='newcityadd.php?id=" . htmlspecialchars($row['id']) . "' class='btn btn-primary'>Edit</a></td>";
                                echo "<td><a href='#' class='btn btn-danger' data-bs-toggle='modal' data-bs-target='#deleteModal' onclick='setDeleteId(" . htmlspecialchars($row['id']) . ")'>Delete</a></td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='6'>No results found.</td></tr>";
                        }

                        $stmt->close();
                        $con->close();
                        ?>
                    </tbody>
                </table>

                <!-- Delete Confirmation Modal -->
                <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="deleteModalLabel">Confirm Deletion</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                Are you sure you want to delete this city?
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                <a id="confirmDelete" class="btn btn-danger">Delete</a>
                            </div>
                        </div>
                    </div>
                </div>

                <script>
                    function setDeleteId(id) {
                        const deleteLink = document.getElementById('confirmDelete');
                        deleteLink.href = 'cityDelete.php?id=' + id;
                    }
                </script>

                <!-- Pagination -->
                <nav aria-label="Page navigation">
                    <ul class="pagination justify-content-center">
                        <?php if ($page > 1): ?>
                            <li class="page-item">
                                <a class="page-link"
                                    href="?page=<?php echo $page - 1; ?>&search=<?php echo urlencode($search); ?>&order_by=<?php echo $order_by; ?>&sort_order=<?php echo $sort_order; ?>"
                                    aria-label="Previous">
                                    <span aria-hidden="true">&laquo;</span>
                                </a>
                            </li>
                        <?php else: ?>
                            <li class="page-item disabled">
                                <span class="page-link" aria-label="Previous">&laquo;</span>
                            </li>
                        <?php endif; ?>

                        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                            <li class="page-item <?php echo ($i === $page) ? 'active' : ''; ?>">
                                <a class="page-link"
                                    href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&order_by=<?php echo $order_by; ?>&sort_order=<?php echo $sort_order; ?>"><?php echo $i; ?></a>
                            </li>
                        <?php endfor; ?>

                        <?php if ($page < $total_pages): ?>
                            <li class="page-item">
                                <a class="page-link"
                                    href="?page=<?php echo $page + 1; ?>&search=<?php echo urlencode($search); ?>&order_by=<?php echo $order_by; ?>&sort_order=<?php echo $sort_order; ?>"
                                    aria-label="Next">
                                    <span aria-hidden="true">&raquo;</span>
                                </a>
                            </li>
                        <?php else: ?>
                            <li class="page-item disabled">
                                <span class="page-link" aria-label="Next">&raquo;</span>
                            </li>
                        <?php endif; ?>
                    </ul>
                </nav>
                <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
                    integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p"
                    crossorigin="anonymous"></script>
            </div>
        </div>
    </div>
</body>

</html>