<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($id) ? 'Update City' : 'Add City'; ?></title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .container {
            max-width: 600px;
            margin-top: 50px;
        }

        .form-container {
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            background-color: #ffffff;
        }

        .form-header {
            margin-bottom: 20px;
        }
    </style>
</head>

<body>
    <?php
    session_start();
    include("conn.php");


    $name = $id = $country_id = $state_id = '';
    $states = [];
    $country_valid = $state_valid = $name_valid = true;
    $city_exists_error = '';

    
    if (isset($_GET['id'])) {
        $id = (int) $_GET['id']; 
        $stmt = $con->prepare("SELECT city.*, country.id AS country_id, states.id AS state_id 
                                FROM city 
                                JOIN states ON city.state_id = states.id 
                                JOIN country ON states.country_id = country.id 
                                WHERE city.id = ?");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($row = $result->fetch_assoc()) {
            $state_id = $row['state_id'];
            $name = $row['c_name'];
            $country_id = $row['country_id'];
        }
    }

    // Handle form submission

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $name = trim($_POST['name']);
        $state_id = $_POST['state_id'];
        $country_id = $_POST['country_id'];

        // Validation

        $name_valid = !empty($name) && preg_match('/^[a-zA-Z\s]+$/', $name);
        $country_valid = !empty($country_id);
        $state_valid = !empty($state_id);

        if ($name_valid && $country_valid && $state_valid) {
            $stmt = $con->prepare("SELECT COUNT(*) FROM city WHERE c_name = ? AND state_id = ?" . ($id ? " AND id <> ?" : ""));
            if ($id) {
                $stmt->bind_param('sii', $name, $state_id, $id);
            } else {
                $stmt->bind_param('si', $name, $state_id);
            }
            $stmt->execute();
            $stmt->bind_result($exists);
            $stmt->fetch();
            $stmt->close();

            if ($exists) {
                $city_exists_error = "The city '{$name}' already exists in the selected state.";
                $name_valid = false; 
            } else {
                if ($id) {
                    $stmt = $con->prepare("UPDATE city SET c_name = ?, state_id = ? WHERE id = ?");
                    $stmt->bind_param('ssi', $name, $state_id, $id);
                } else {
                    $stmt = $con->prepare("INSERT INTO city (c_name, state_id) VALUES (?, ?)");
                    $stmt->bind_param('si', $name, $state_id);
                }

                if ($stmt->execute()) {
                    header("Location: city.php?status=" . ($id ? "update" : "success"));
                    exit();
                } else {
                    $name_valid = false; 
                }
            }
        }
    }

    if (!empty($country_id)) {
        $stmt = $con->prepare("SELECT id, s_name FROM states WHERE country_id = ?");
        $stmt->bind_param('i', $country_id);
        $stmt->execute();
        $states = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
    ?>


    <div class="container">
        <div class="form-container">
            <h2 class="form-header text-center"><?php echo ($id) ? 'Update City' : 'Add City'; ?></h2>

            <form method="POST">
                <div class="form-group">
                    <label for="country">Select Country</label>
                    <select id="country_id" name="country_id"
                        class="form-control <?php echo !$country_valid ? 'is-invalid' : ''; ?>"
                        onchange="this.form.submit();">
                        <option value="">Select Country</option>
                        <?php
                        $stmt = $con->prepare("SELECT id, name FROM country");
                        $stmt->execute();
                        $result = $stmt->get_result();
                        while ($row = $result->fetch_assoc()) {
                            $selected = ($row['id'] == $country_id) ? 'selected' : '';
                            echo "<option value=\"{$row['id']}\" $selected>{$row['name']}</option>";
                        }
                        ?>
                    </select>
                    <div class="invalid-feedback">Please select a country.</div>
                </div>

                <div class="form-group">
                    <label for="state">Select State</label>
                    <select id="state_id" name="state_id"
                        class="form-control <?php echo !$state_valid ? 'is-invalid' : ''; ?>">
                        <option value="">Select State</option>
                        <?php foreach ($states as $state): ?>
                            <option value="<?php echo $state['id']; ?>" <?php echo ($state['id'] == $state_id) ? 'selected' : ''; ?>><?php echo $state['s_name']; ?></option>
                        <?php endforeach; ?>
                    </select>
                    <div class="invalid-feedback">Please select a state.</div>
                </div>

                <div class="form-group">
                    <label for="name">Enter City Name</label>
                    <input type="text" class="form-control <?php echo !$name_valid || !empty($city_exists_error) ? 'is-invalid' : ''; ?>" name="name"
                        value="<?php echo htmlspecialchars($name); ?>" placeholder="Enter city name">
                    <div class="invalid-feedback">
                        <?php echo !empty($city_exists_error) ? htmlspecialchars($city_exists_error) : 'Please enter a valid city name.'; ?>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary">Submit</button>
                <p>Don't want to add a city? <a href="city.php">Go Back</a></p>
            </form>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>
