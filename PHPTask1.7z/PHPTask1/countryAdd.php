<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Country</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .container {
            max-width: 600px;
            margin-top: 50px;
        }

        .form-container {
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            background-color: #ffffff;
        }

        .form-header {
            margin-bottom: 20px;
        }
    </style>
</head>

<body>

    <?php
    session_start();
    include("conn.php");

    $name = '';
    $id = null;
    $nameError = '';
    $existsError = '';

    if (isset($_GET['id'])) {
        $id = $_GET['id'];
        $stmt = $con->prepare("SELECT name FROM country WHERE id = ?");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($row = $result->fetch_assoc()) {
            $name = $row['name'];
        }
    }

    if (isset($_POST['submit'])) {
        $name = trim($_POST['name']);
    
        if (empty($name)) {
            $nameError = "Please Enter Country Name.";
        } elseif (!preg_match('/^[a-zA-Z]/', $name)) {
            $nameError = "Please Enter Correct Country Name.";
        } else {
            if ($id) {
                $stmt = $con->prepare("SELECT * FROM country WHERE name = ? AND id != ?");
                $stmt->bind_param("si", $name, $id);
                $stmt->execute();
                $result = $stmt->get_result();
    
                if ($result->num_rows > 0) {
                    $existsError = "This Country Already Exists, Please Insert New Record.";
                } else {
                    $stmt = $con->prepare("UPDATE country SET name = ? WHERE id = ?");
                    $stmt->bind_param('si', $name, $id);
                    if ($stmt->execute()) {
                        header("Location: country.php?status=update");
                        exit();
                    }
                }
            } else {
                $stmt = $con->prepare("SELECT * FROM country WHERE name = ?");
                $stmt->bind_param('s', $name);
                $stmt->execute();
                $result = $stmt->get_result();
    
                if ($result->num_rows > 0) {
                    $existsError = "This Country Already Exists, Please Insert New Record.";
                } else {
                      $stmt->close();
                    $stmt = $con->prepare("INSERT INTO country (name) VALUES (?)");
                    $stmt->bind_param('s', $name);
                    if ($stmt->execute()) {
                        header('Location: country.php?status=success');
                        exit();
                    }
                }
            }
            $stmt->close();
        }
    }
    
  
    $con->close();
    ?>

    <div class="container">
        <div class="form-container">
            <h2 class="form-header text-center"><?php echo $id ? 'Update Country' : 'Add Country'; ?></h2>
            <form method="POST">
                <div class="form-group">
                    <label for="name">Enter Country Name</label>
                    <input type="text"
                        class="form-control <?php echo $nameError || $existsError ? 'is-invalid' : ''; ?>" name="name"
                        value="<?php echo htmlspecialchars($name); ?>" placeholder="Enter country name">
                    <?php if ($nameError): ?>
                        <div class="invalid-feedback">
                            <?php echo $nameError; ?>
                        </div>
                    <?php endif; ?>
                    <?php if ($existsError): ?>
                        <div class="invalid-feedback">
                            <?php echo $existsError; ?>
                        </div>
                    <?php endif; ?>
                </div>
                <button type="submit" name="submit" class="btn btn-primary btn-block mb-3">Submit</button>
                <p>Don't want to add a country? <a href="country.php">Go Back</a></p>
            </form>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>