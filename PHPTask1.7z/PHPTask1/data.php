<?php
require 'vendor/autoload.php'; // Include PhpSpreadsheet

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

include("conn.php");
session_start();

$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$query = "SELECT * FROM country" . ($search ? " WHERE name LIKE ?" : "");

$stmt = $con->prepare($query);
if ($search) {
    $searchParam = "%$search%";
    $stmt->bind_param('s', $searchParam);
}
$stmt->execute();
$result = $stmt->get_result();

// Create a new Spreadsheet object
$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();

// Set headers
$sheet->setCellValue('A1', 'ID');
$sheet->setCellValue('B1', 'Name');

// Fill data
$row = 2; // Start from the second row
while ($data = $result->fetch_assoc()) {
    $sheet->setCellValue('A' . $row, $data['id']);
    $sheet->setCellValue('B' . $row, $data['name']);
    $row++;
}

// Set headers for Excel file download
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment; filename="countries.xlsx"');

// Write and output the file
$writer = new Xlsx($spreadsheet);
$writer->save('php://output');
$conn->close();
exit();
?>
