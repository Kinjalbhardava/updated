<?php

include("conn.php");

// Initialize variables
$country_id = '';
$state_id = '';
$selected_country = '';
$selected_state = '';

// Fetch countries
$countries = $con->query("SELECT id, name FROM country");

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!empty($_POST['country_id'])) {
        $selected_country = $_POST['country_id'];
        
        // Fetch states based on selected country
        $states = $con->prepare("SELECT id, s_name FROM states WHERE country_id = ?");
        $states->bind_param('i', $selected_country);
        $states->execute();
        $state_result = $states->get_result();

        // Check if a state is selected
        if (!empty($_POST['state_id'])) {
            $selected_state = $_POST['state_id'];

            // Fetch cities based on selected state
            $cities = $con->prepare("SELECT id, c_name FROM city WHERE state_id = ?");
            $cities->bind_param('i', $selected_state);
            $cities->execute();
            $city_result = $cities->get_result();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Country, State, City Dropdown</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

<div class="container mt-5">
    <h2>Select Country, State, and City</h2>
    <form method="POST">
        <div class="form-group">
            <label for="country_id">Select Country</label>
            <select id="country_id" name="country_id" class="form-control" onchange="this.form.submit();" required>
                <option value="">Select Country</option>
                <?php while ($row = $countries->fetch_assoc()): ?>
                    <option value="<?php echo $row['id']; ?>" <?php echo ($row['id'] == $selected_country) ? 'selected' : ''; ?>>
                        <?php echo $row['name']; ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>

        <?php if (!empty($selected_country)): ?>
            <div class="form-group">
                <label for="state_id">Select State</label>
                <select id="state_id" name="state_id" class="form-control" onchange="this.form.submit();" required>
                    <option value="">Select State</option>
                    <?php
                    // Fetch states based on the selected country
                    $states = $con->prepare("SELECT id, s_name FROM states WHERE country_id = ?");
                    $states->bind_param('i', $selected_country);
                    $states->execute();
                    $state_result = $states->get_result();
                    
                    while ($row = $state_result->fetch_assoc()): ?>
                        <option value="<?php echo $row['id']; ?>" <?php echo ($row['id'] == $selected_state) ? 'selected' : ''; ?>>
                            <?php echo $row['s_name']; ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
        <?php endif; ?>

        <?php if (!empty($selected_state)): ?>
            <div class="form-group">
                <label for="city_id">Select City</label>
                <select id="city_id" name="city_id" class="form-control" required>
                    <option value="">Select City</option>
                    <?php
                    // Fetch cities based on the selected state
                    $cities = $con->prepare("SELECT id, c_name FROM city WHERE state_id = ?");
                    $cities->bind_param('i', $selected_state);
                    $cities->execute();
                    $city_result = $cities->get_result();
                    
                    while ($row = $city_result->fetch_assoc()): ?>
                        <option value="<?php echo $row['id']; ?>">
                            <?php echo $row['c_name']; ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
        <?php endif; ?>
    </form>
</div>

</body>
</html>
