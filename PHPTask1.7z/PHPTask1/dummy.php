<?php
include("conn.php");
session_start();

// Search and order
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$sort_order = 'ASC';  
$order_by = 'id';   
$items_per_page = 5; 

$page = max((int) ($_GET['page'] ?? 1), 1);
$offset = ($page - 1) * $items_per_page;

if (isset($_GET['order_by']) && in_array($_GET['order_by'], ['id', 'name'])) {
    $order_by = $_GET['order_by'];
}

if (isset($_GET['sort_order']) && in_array($_GET['sort_order'], ['ASC', 'DESC'])) {
    $sort_order = $_GET['sort_order'];
}

// Toggle sorting order for the next click

$next_sort_order = $sort_order === 'ASC' ? 'DESC' : 'ASC';

// Total record count

$countQuery = "SELECT COUNT(*) FROM country" . ($search ? " WHERE name LIKE ?" : "");
$countStmt = $con->prepare($countQuery);
if ($search) {
    $searchParam = "%$search%";
    $countStmt->bind_param('s', $searchParam);
}
$countStmt->execute();
$total = $countStmt->get_result()->fetch_row()[0];
$total_pages = ceil($total / $items_per_page);

$query = "SELECT * FROM country" . ($search ? " WHERE name LIKE ?" : "") . " ORDER BY $order_by $sort_order LIMIT ?, ?";
$stmt = $con->prepare($query);
if ($search) {
    $stmt->bind_param('sii', $searchParam, $offset, $items_per_page);
} else {
    $stmt->bind_param('ii', $offset, $items_per_page);
}
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }

        #sidebar {
            min-height: 100vh;
        }

        .table-hover tbody tr:hover {
            background-color: #e9ecef;
        }

        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }

        .row1 h2 {
            margin-bottom: 25px;
        }

        .fas {
            margin-right: 20px;
        }

        .nav-link {
            color: rgb(41, 41, 182);
            margin-bottom: 10px;
        }

        a {
            text-decoration: none;
        }

        .container {
            max-width: 600px;
            margin-top: 50px;
        }

        .form-container {
            padding: 30px;
            margin-left: -100px;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            background-color: #ffffff;
        }

        .form-header {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-2 bg-light text-dark p-4" id="sidebar">
                <h2 class="ps-4 pb-3">Admin</h2>
                <ul class="nav flex-column">
                    <li class="nav-item"><a class="nav-link active" href="index.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="country.php"><i class="fas fa-flag"></i> Country</a></li>
                    <li class="nav-item"><a class="nav-link" href="state.php"><i class="fas fa-map-marker-alt"></i> State</a></li>
                    <li class="nav-item"><a class="nav-link" href="city.php"><i class="fas fa-building"></i> City</a></li>
                </ul>
            </div>
            <div class="col-md-10 p-4" id="main-content">
                <div class="row mb-4">
                    <div class="col">
                        <h3><i class="fas fa-globe"></i> Countries Listing</h3>
                    </div>
                </div>


    <form method="GET" class="row mb-3">
        <div class="col col-lg-3">
            <input class="form-control" type="search" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Search" aria-label="Search">
        </div>
        <div class="col-auto">
            <button type="submit" class="btn btn-success mb-3">Search</button>
        </div>
        <div class="col col-lg-5"></div>
        <div class="col">
            <a href="newcountryadd.php" class="btn btn-primary mb-3"><i class="fas fa-plus me-2"></i> Add Country</a>
        </div>
    </form>

    <table class="table table-striped">
        <thead>
            <tr>
                <th><a href="?page=<?php echo $page; ?>&search=<?php echo urlencode($search); ?>&order_by=id&sort_order=<?php echo $next_sort_order; ?>">Country ID</a></th>
                <th><a href="?page=<?php echo $page; ?>&search=<?php echo urlencode($search); ?>&order_by=name&sort_order=<?php echo $next_sort_order; ?>">Country Name</a></th>
                <th>Edit Country</th>
                <th>Delete Country</th>
            </tr>
        </thead>
        <tbody>
            <?php
if (isset($_GET['status'])) {
    $statusMessages = [
        'success' => "Your record has been inserted successfully!",
        'delete' => "Your record was deleted successfully!",
        'update' => "Data updated successfully!"
    ];
    echo "<div class='alert alert-" . ($_GET['status'] === 'delete' ? 'danger' : 'success') . " alert-dismissible fade show' role='alert'>"
        . $statusMessages[$_GET['status']]
        . "<button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>"
        . "</div>";
}

?>

            <?php if ($result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['id']); ?></td>
                        <td><?php echo htmlspecialchars($row['name']); ?></td>
                        <td><a href='newcountryadd.php?id=<?php echo $row['id']; ?>' class='btn btn-primary'>Edit</a></td>
                        <td><a href='#' class='btn btn-danger' data-bs-toggle='modal' data-bs-target='#deleteModal' onclick='setDeleteId(<?php echo $row['id']; ?>)'>Delete</a></td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="4">No results found.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>

    <!-- Pagination Links -->

    <nav aria-label="Page navigation">
    <ul class="pagination justify-content-center">
        <?php if ($page > 1): ?>
            <li class="page-item">
                <a class="page-link" href="?page=<?php echo $page - 1; ?>&search=<?php echo urlencode($search); ?>&order_by=<?php echo $order_by; ?>&sort_order=<?php echo $sort_order; ?>" aria-label="Previous">
                    <span aria-hidden="true">&laquo;</span>
                </a>
            </li>
        <?php else: ?>
            <li class="page-item disabled">
                <span class="page-link" aria-label="Previous">&laquo;</span>
            </li>
        <?php endif; ?>

        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
            <li class="page-item <?php echo ($i === $page) ? 'active' : ''; ?>">
                <a class="page-link" href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&order_by=<?php echo $order_by; ?>&sort_order=<?php echo $sort_order; ?>"><?php echo $i; ?></a>
            </li>
        <?php endfor; ?>

        <?php if ($page < $total_pages): ?>
            <li class="page-item">
                <a class="page-link" href="?page=<?php echo $page + 1; ?>&search=<?php echo urlencode($search); ?>&order_by=<?php echo $order_by; ?>&sort_order=<?php echo $sort_order; ?>" aria-label="Next">
                    <span aria-hidden="true">&raquo;</span>
                </a>
            </li>
        <?php else: ?>
            <li class="page-item disabled">
                <span class="page-link" aria-label="Next">&raquo;</span>
            </li>
        <?php endif; ?>
    </ul>
</nav>

    <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="deleteModalLabel">Confirm Deletion</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    Are you sure you want to delete this country?
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <a id="confirmDelete" class="btn btn-danger">Delete</a>
                </div>
            </div>
        </div>
    </div>

    <script>
        function setDeleteId(id) {
            const deleteLink = document.getElementById('confirmDelete');
            deleteLink.href = 'countryDelete.php?id=' + id;
        }
    </script>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
$stmt->close();
$con->close();
?>
    