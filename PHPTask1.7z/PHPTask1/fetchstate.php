<?php
session_start();
include("conn.php");

if (isset($_GET['country_id'])) {
    $country_id = (int) $_GET['country_id'];

    $stmt = $con->prepare("SELECT id, s_name FROM states WHERE country_id = ?");
    $stmt->bind_param('i', $country_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $states = [];
    while ($row = $result->fetch_assoc()) {
        $states[] = $row;
    }

    echo json_encode($states);
}
?>
