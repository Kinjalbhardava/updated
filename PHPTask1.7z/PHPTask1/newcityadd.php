<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }

        #sidebar {
            min-height: 100vh;
        }

        .table-hover tbody tr:hover {
            background-color: #e9ecef;
        }

        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }

        .row1 h2 {
            margin-bottom: 25px;
        }

        .fas {
            margin-right: 20px;
        }

        .nav-link {
            color: rgb(41, 41, 182);
            margin-bottom: 10px;
        }

        a {
            text-decoration: none;
        }

        .container {
            max-width: 600px;
            margin-top: 50px;
        }

        .form-container {
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            background-color: #ffffff;
        }

        .form-header {
            margin-bottom: 20px;
        }
    </style>
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-2 bg-light text-dark p-4" id="sidebar">
                <h2 class="ps-4 pb-3">Admin</h2>
                <ul class="nav flex-column">
                    <li class="nav-item"><a class="nav-link active" href="index.php"><i
                                class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="country.php"><i class="fas fa-flag"></i> Country</a>
                    </li>
                    <li class="nav-item"><a class="nav-link" href="state.php"><i class="fas fa-map-marker-alt"></i>
                            State</a></li>
                    <li class="nav-item"><a class="nav-link" href="city.php"><i class="fas fa-building"></i> City</a>
                    </li>
                </ul>
            </div>

            <?php
            session_start();
            include("conn.php");

            $name = '';
            $id = isset($_GET['id']) ? (int) $_GET['id'] : '';
            $country_id = '';
            $state_id = '';
            $cities = [];
            $city_exists_error = '';
            $city_empty_error = '';
            $city_pattern_match = '';
            $name_valid = $country_valid = $state_valid = true;

            // Fetch city data for update

            if ($id) {
                $stmt = $con->prepare("SELECT city.*, states.country_id FROM city 
                                        JOIN states ON city.state_id = states.id 
                                        WHERE city.id = ?");
                $stmt->bind_param('i', $id);
                $stmt->execute();
                $result = $stmt->get_result();

                if ($row = $result->fetch_assoc()) {
                    $state_id = $row['state_id'];
                    $name = $row['c_name'];
                    $country_id = $row['country_id'];
                }
                $stmt->close();
            }

            // Fetch states based on selected country

            if (!empty($country_id)) {
                $stmt = $con->prepare("SELECT id, s_name FROM states WHERE country_id = ?");
                $stmt->bind_param('i', $country_id);
                $stmt->execute();
                $result = $stmt->get_result();
                while ($row = $result->fetch_assoc()) {
                    $states[] = $row;
                }
                $stmt->close();
            }

            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $name = trim($_POST['name']);
                $state_id = $_POST['state_id'];
                $country_id = $_POST['country_id'];

                // Validate inputs
                $name_valid = !empty($name) && preg_match('/^[a-zA-Z\s]+$/', $name);
                $country_valid = !empty($country_id);
                $state_valid = !empty($state_id);

                if (empty($name)) {
                    $city_empty_error = "Please enter city name.";
                } elseif (!preg_match('/^[a-zA-Z\s]+$/', $name)) {
                    $city_pattern_match = "Please enter a valid city name.";
                } elseif ($name_valid && $country_valid && $state_valid) {

                    // Check for existing city name within the same state

                    $stmt = $con->prepare("SELECT COUNT(*) FROM city WHERE c_name = ? AND state_id = ? AND (id != ? OR ? = 0)");
                    $stmt->bind_param('siii', $name, $state_id, $id, $id);
                    $stmt->execute();
                    $stmt->bind_result($exists);
                    $stmt->fetch();
                    $stmt->close();

                    if ($exists) {
                        $city_exists_error = "The city '{$name}' already exists in this state. Please choose a different name.";
                    } else {
                        // Insert or update city
                        if ($id) {
                            $stmt = $con->prepare("UPDATE city SET c_name = ?, state_id = ? WHERE id = ?");
                            $stmt->bind_param('ssi', $name, $state_id, $id);
                        } else {
                            $stmt = $con->prepare("INSERT INTO city (c_name, state_id) VALUES (?, ?)");
                            $stmt->bind_param('si', $name, $state_id);
                        }   

                        if ($stmt->execute()) {
                            header("Location: city.php?status=" . ($id ? "update" : "success"));
                            exit();
                        } else {
                            $city_exists_error = "Database error: " . $stmt->error;
                        }
                    }
                } else {
                   
                    
                }
            }
            ?>

            <div class="container">
                <div class="form-container">
                    <h2 class="form-header text-center"><?php echo ($id) ? 'Update City' : 'Add City'; ?></h2>
                    <form method="POST">
                        <div class="form-group">
                            <label for="country_id" class="mb-2">Select Country</label>
                            <select id="country_id" name="country_id"
                                class="form-control mb-2 <?php echo !$country_valid ? 'is-invalid' : ''; ?>"
                                onchange="fetchStates();">
                                <option value="">Select Country</option>
                                <?php
                                $stmt = $con->prepare("SELECT id, name FROM country");
                                $stmt->execute();
                                $result = $stmt->get_result();
                                while ($row = $result->fetch_assoc()) {
                                    $selected = ($row['id'] == $country_id) ? 'selected' : '';
                                    echo "<option value=\"{$row['id']}\" $selected>{$row['name']}</option>";
                                }
                                $stmt->close();
                                ?>
                            </select>
                            <div class="invalid-feedback">Please select a country.</div>
                        </div>

                        <div class="form-group">
                            <label for="state_id" class="mb-2">Select State</label>
                            <select id="state_id" name="state_id"
                                class="form-control mb-2 <?php echo !$state_valid ? 'is-invalid' : ''; ?>">
                                <option value="">Select State</option>
                                <?php
                                if (!empty($country_id)) {
                                    $stmt = $con->prepare("SELECT id, s_name FROM states WHERE country_id = ?");
                                    $stmt->bind_param('i', $country_id);
                                    $stmt->execute();
                                    $result = $stmt->get_result();
                                    while ($row = $result->fetch_assoc()) {
                                        $selected = ($row['id'] == $state_id) ? 'selected' : '';
                                        echo "<option value=\"{$row['id']}\" $selected>{$row['s_name']}</option>";
                                    }
                                    $stmt->close();
                                }
                                ?>
                            </select>
                            <div class="invalid-feedback">Please select a State.</div>
                        </div>


                        <div class="form-group">
                            <label for="name" class="mb-2">Enter City Name</label>
                            <input type="text"
                                class="form-control mb-2 <?php echo !$name_valid || !empty($city_exists_error) ? 'is-invalid' : ''; ?>"
                                name="name" value="<?php echo htmlspecialchars($name); ?>"
                                placeholder="Enter city name">

                            <div class="invalid-feedback">
                                <?php echo $city_empty_error ?: $city_pattern_match; ?>
                            </div>
                            <div class="invalid-feedback">
                                <?php echo $city_exists_error; ?>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary mb-2 mt-2">Submit</button>
                        <p>Don't want to add a city? <a href="city.php">Go Back</a></p>
                    </form>
                </div>
            </div>

            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
            <script>
                function fetchStates() {
                    const countryId = document.getElementById('country_id').value;
                    const stateSelect = document.getElementById('state_id');
                    stateSelect.innerHTML = '<option value="">Select State</option>';

                    if (countryId) {
                        fetch('fetchstate.php?country_id=' + countryId)
                            .then(response => response.json())
                            .then(data => {
                                if (data.length > 0) {
                                    data.forEach(function (state) {
                                        const option = document.createElement('option');
                                        option.value = state.id;
                                        option.textContent = state.s_name;
                                        stateSelect.appendChild(option);
                                    });
                                } else {
                                    const option = document.createElement('option');
                                    option.value = '';
                                    option.textContent = 'No states available';
                                    stateSelect.appendChild(option);
                                }
                            })
                            .catch(error => console.error('Error fetching states:', error));
                    }
                }
            </script>
        </div>
    </div>
</body>

</html>
