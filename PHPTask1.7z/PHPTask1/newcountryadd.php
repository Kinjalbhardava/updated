<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }

        #sidebar {
            min-height: 100vh;
        }

        .table-hover tbody tr:hover {
            background-color: #e9ecef;
        }

        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }

        .row1 h2 {
            margin-bottom: 25px;
        }

        .fas {
            margin-right: 20px;
        }

        .nav-link {
            color: rgb(41, 41, 182);
            margin-bottom: 10px;
        }
        a{
            text-decoration: none;
        }

        .container {
            max-width: 600px;
            margin-top: 50px;
        }

        .form-container {
            padding: 30px;
            margin-left: -100px;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            background-color: #ffffff;
        }

        .form-header {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-2 bg-light text-dark p-4" id="sidebar">
            <h2 class="ps-4 pb-3">Admin</h2>
            <ul class="nav flex-column">
                <li class="nav-item"><a class="nav-link active" href="index.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li class="nav-item"><a class="nav-link" href="country.php"><i class="fas fa-flag"></i> Country</a></li>
                <li class="nav-item"><a class="nav-link" href="state.php"><i class="fas fa-map-marker-alt"></i> State</a></li>
                <li class="nav-item"><a class="nav-link" href="city.php"><i class="fas fa-building"></i> City</a></li>
            </ul>
        </div>

        <?php
        session_start();
        include("conn.php");

        $name = '';
        $id = null;
        $nameError = '';
        $existsError = '';

        if (isset($_GET['id'])) {
            $id = (int)$_GET['id'];
            $stmt = $con->prepare("SELECT name FROM country WHERE id = ?");
            $stmt->bind_param('i', $id);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($row = $result->fetch_assoc()) {
                $name = $row['name'];
            }
        }

        // Handle form submission
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = trim($_POST['name']);

            if (empty($name)) {
                $nameError = "Please Enter Country Name.";
            } elseif (!preg_match('/^[a-zA-Z\s]+$/', $name)) { 
                $nameError = "Please Enter a Valid Country Name.";
            } else {
                if ($id) {
                    $stmt = $con->prepare("SELECT * FROM country WHERE name = ? AND id != ?");
                    $stmt->bind_param("si", $name, $id);
                } else {
                    $stmt = $con->prepare("SELECT * FROM country WHERE name = ?");
                    $stmt->bind_param('s', $name);
                }
                $stmt->execute();
                $result = $stmt->get_result();

                if ($result->num_rows > 0) {
                    $existsError = "This Country Already Exists. Please Insert a New Record.";
                } else {
                    if ($id) {
                        $stmt = $con->prepare("UPDATE country SET name = ? WHERE id = ?");
                        $stmt->bind_param('si', $name, $id);
                    } else {
                        $stmt = $con->prepare("INSERT INTO country (name) VALUES (?)");
                        $stmt->bind_param('s', $name);
                    }
                    if ($stmt->execute()) {
                        header("Location: country.php?status=" . ($id ? 'update' : 'success'));
                        exit();
                    }
                }
                $stmt->close();
            }
        }

        $con->close();
        ?>

        <div class="container">
            <div class="form-container">
                <h2 class="form-header text-center"><?php echo $id ? 'Update Country' : 'Add Country'; ?></h2>
                <form method="POST">
                    <div class="form-group">
                        <label for="name" class="mb-2">Enter Country Name</label><br>
                        <input type="text" class="form-control <?php echo $nameError || $existsError ? 'is-invalid' : ''; ?>" name="name" value="<?php echo htmlspecialchars($name); ?>" placeholder="Enter country name">
                        <?php if ($nameError): ?>
                            <div class="invalid-feedback"><?php echo $nameError; ?></div>
                        <?php endif; ?>
                        <?php if ($existsError): ?>
                            <div class="invalid-feedback"><?php echo $existsError; ?></div>
                        <?php endif; ?>
                    </div>
                    <button type="submit" name="submit" class="btn btn-primary btn-block mb-3 mt-3">Submit</button>
                    <p>Don't want to add a country? <a href="country.php">Go Back</a></p>
                </form>
            </div>
        </div>

    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
