<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }

        #sidebar {
            min-height: 100vh;
        }

        .table-hover tbody tr:hover {
            background-color: #e9ecef;
        }

        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }

        .row1 h2 {
            margin-bottom: 25px;
        }

        .fas {
            margin-right: 20px;
        }

        .nav-link {
            color: rgb(41, 41, 182);
            margin-bottom: 10px;
        }

        a {
            text-decoration: none;
        }

        .container {
            max-width: 600px;
            margin-top: 50px;
        }

        .form-container {
            padding: 30px;
            margin-left: -100px;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            background-color: #ffffff;
        }

        .form-header {
            margin-bottom: 20px;
        }
    </style>
</head>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-2 bg-light text-dark p-4" id="sidebar">
            <h2 class="ps-4 pb-3">Admin</h2>
            <ul class="nav flex-column">
                <li class="nav-item"><a class="nav-link active" href="index.php"><i class="fas fa-tachometer-alt"></i>
                        Dashboard</a></li>
                <li class="nav-item"><a class="nav-link" href="country.php"><i class="fas fa-flag"></i> Country</a>
                </li>
                <li class="nav-item"><a class="nav-link" href="state.php"><i class="fas fa-map-marker-alt"></i>
                        State</a></li>
                <li class="nav-item"><a class="nav-link" href="city.php"><i class="fas fa-building"></i> City</a>
                </li>
            </ul>
        </div>

        <?php
        session_start();
        include("conn.php");

        $name = '';
        $id = isset($_GET['id']) ? (int) $_GET['id'] : '';
        $country_id = '';
        $state_exists_error = '';
        $state_pattern_match = '';
        $state_empty_error = '';
        $name_valid = $country_valid = true;

        // Fetch existing state data for update
        
        if ($id) {
            $stmt = $con->prepare("SELECT s_name, country_id FROM states WHERE id = ?");
            $stmt->bind_param('i', $id);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($row = $result->fetch_assoc()) {
                $name = $row['s_name'];
                $country_id = $row['country_id'];
            }
            $stmt->close();
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = trim($_POST['name']);
            $country_id = (int) $_POST['country_id'];

            $name_valid = !empty($name) && preg_match('/^[a-zA-Z\s]+$/', $name);
            $country_valid = !empty($country_id);

            if(empty($name)){
                $state_empty_error = "Please Enter State Name";
            }
            elseif(!preg_match('/^[a-zA-Z\s]+$/', $name)){
$state_pattern_match = "Please Enter Valid State Name";

            }
            elseif ($name_valid && $country_valid) {

                // Check if state name exists in the same country only if updating
        
                if ($id) {
                    $stmt = $con->prepare("SELECT COUNT(*) FROM states WHERE s_name = ? AND country_id = ? AND id != ?");
                    $stmt->bind_param('sii', $name, $country_id, $id);
                } else {
                    $stmt = $con->prepare("SELECT COUNT(*) FROM states WHERE s_name = ? AND country_id = ?");
                    $stmt->bind_param('si', $name, $country_id);
                }

                $stmt->execute();
                $stmt->bind_result($exists);
                $stmt->fetch();
                $stmt->close();

                if ($exists) {
                    $state_exists_error = "The state '{$name}' already exists in this country. Please choose a different name for this country.";
                    $name_valid = false;
                }

                if ($name_valid) {
                    if ($id) {
                        $stmt = $con->prepare("UPDATE states SET s_name = ?, country_id = ? WHERE id = ?");
                        $stmt->bind_param('ssi', $name, $country_id, $id);
                    } else {
                        $stmt = $con->prepare("INSERT INTO states (s_name, country_id) VALUES (?, ?)");
                        $stmt->bind_param('si', $name, $country_id);
                    }

                    if ($stmt->execute()) {
                        header("Location: state.php?status=" . ($id ? "update" : "success"));
                        exit();
                    } else {
                        $state_exists_error = "Database error: " . $stmt->error;
                    }
                }
            } 
        }
        ?>

        <div class="container">
            <div class="form-container">
                <h2 class="text-center"><?php echo $id ? 'Update State' : 'Add State'; ?></h2>
                <form method="POST" novalidate>
                    <div class="form-group">
                        <label for="country_id" class="mb-2 mt-2">Select Country</label>
                        <select id="country_id" name="country_id"
                            class="form-control <?php echo !$country_valid ? 'is-invalid' : ''; ?>">
                            <option value="">Select Country</option>
                            <?php
                            $stmt = $con->prepare("SELECT id, name FROM country");
                            $stmt->execute();
                            $result = $stmt->get_result();

                            while ($row = $result->fetch_assoc()) {
                                $selected = ($row['id'] == $country_id) ? 'selected' : '';
                                echo "<option value=\"{$row['id']}\" $selected>{$row['name']}</option>";
                            }
                            $stmt->close();
                            ?>
                        </select>
                        <div class="invalid-feedback">Please select a country.</div>
                    </div>
                    <div class="form-group">
                        <label for="name" class="mb-2 mt-2">Enter State Name</label>
                        <input type="text" class="form-control <?php echo !$name_valid ? 'is-invalid' : ''; ?>"
                            name="name" value="<?php echo htmlspecialchars($name, ENT_QUOTES, 'UTF-8'); ?>"
                            placeholder="Enter state name">

                        <div class="invalid-feedback">
                            <?php echo htmlspecialchars($state_exists_available_error); ?>
                        </div>
                        <div class="invalid-feedback"> <?php echo htmlspecialchars($state_pattern_error); ?>
                        </div>
                        <div class="invalid-feedback">
                            <?php echo htmlspecialchars($state_exists_error); ?>
                        </div>
                        <div class="invalid-feedback">
                            <?php echo htmlspecialchars($state_empty_error); ?>
                        </div>
                        <div class="invalid-feedback">
                            <?php echo htmlspecialchars($state_pattern_match); ?>
                        </div>
                    </div>
                    <input type="submit" name="submit" class="btn btn-primary mb-3 mt-3" value="Submit">
                    <p>Don't want to add a state? <a href="state.php">Go Back</a></p>
                </form>
            </div>
        </div>

    </div>
</div>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>