<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $id ? 'Update State' : 'Add State'; ?></title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .container {
            max-width: 600px;
            margin-top: 50px;
        }
        .form-container {
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            background-color: #ffffff;
        }
        .form-header {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>

<?php
session_start();
include("conn.php");

$name = '';
$id = isset($_GET['id']) ? (int)$_GET['id'] : '';
$country_id = '';
$errorMsgs = [];
$hasError = false;

if ($id) {
    $stmt = $con->prepare("SELECT s_name, country_id FROM states WHERE id = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        $name = $row['s_name'];
        $country_id = (int)$row['country_id']; 
    }
    $stmt->close(); // Close the statement
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $country_id = (int)$_POST['country_id'];

    if (empty($name)) {
        $errorMsgs[] = "Please enter a state name.";
        $hasError = true;
    } elseif (!preg_match('/^[a-zA-Z\s]+$/', $name)) { 
        $errorMsgs[] = "Please enter a valid state name.";
        $hasError = true;
    } elseif (empty($country_id)) {
        $errorMsgs[] = "Please select a country."; 
        $hasError = true;
    }

    if (!$hasError) {
        if ($id) { 
            $stmt = $con->prepare("UPDATE states SET s_name = ?, country_id = ? WHERE id = ?");
            $stmt->bind_param('sii', $name, $country_id, $id);
            if ($stmt->execute()) {
                header("Location: state.php?status=update");
                exit();
            } else {
                $errorMsgs[] = "Error updating state.";
            }
        } else { 
            $stmt = $con->prepare("SELECT * FROM states WHERE s_name = ? AND country_id = ?");
            $stmt->bind_param('si', $name, $country_id);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $errorMsgs[] = "This state already exists for the selected country.";
                $hasError = true;
            } else {
                $stmt = $con->prepare("INSERT INTO states (country_id, s_name) VALUES (?, ?)");
                $stmt->bind_param('is', $country_id, $name);
                if ($stmt->execute()) {
                    header('Location: state.php?status=success');
                    exit();
                } else {
                    $errorMsgs[] = "Error inserting state.";
                }
            }
            $stmt->close(); // Close the statement
        }
    }
}
?>

<div class="container">
    <div class="form-container">
        <h2 class="form-header text-center"><?php echo $id ? 'Update State' : 'Add State'; ?></h2>

        <?php if ($hasError && !empty($errorMsgs)): ?>
            <div class="alert alert-danger">
                <?php foreach ($errorMsgs as $error): ?>
                    <p><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></p>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <form method="POST" novalidate>
            <div class="form-group">
                <label for="country_id">Select Country</label>
                <select id="country_id" name="country_id" class="form-control <?php echo $hasError && empty($country_id) ? 'is-invalid' : ''; ?>" onchange="this.form.submit();">
                    <option value="">Select Country</option>
                    <?php
                    $stmt = $con->prepare("SELECT id, name FROM country");
                    $stmt->execute();
                    $result = $stmt->get_result();

                    while ($row = $result->fetch_assoc()) {
                        $selected = ($row['id'] == $country_id) ? 'selected' : '';
                        echo "<option value=\"{$row['id']}\" $selected>" . htmlspecialchars($row['name'], ENT_QUOTES, 'UTF-8') . "</option>";
                    }
                    $stmt->close(); // Close the statement
                    ?>
                </select>
                <div class="invalid-feedback">Please select a country.</div>
            </div>
            <div class="form-group">
                <label for="name">Enter Name</label>
                <input type="text" class="form-control <?php echo $hasError && empty($name) ? 'is-invalid' : ''; ?>" name="name" value="<?php echo htmlspecialchars($name, ENT_QUOTES, 'UTF-8'); ?>" placeholder="Enter state name" required>
                <div class="invalid-feedback"><?php echo $hasError && empty($name) ? "Please enter a state name." : ""; ?></div>
            </div>
            <input type="submit" name="submit" class="btn btn-primary" value="Submit">
            <p>Don't want to add a state? <a href="state.php">Go Back</a></p>
        </form>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
