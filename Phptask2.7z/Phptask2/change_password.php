<style>
    .backclass{
        text-decoration: none;
        color: #337ab7;
    }
    h3{
        color: #337ab7;
    }
</style>
<?php
session_start();
ob_start();
include("conn.php");
include("header.php");

$passwordError = '';
$confpasswordError = '';
$currentPasswordError = '';
$password_error = '';
$successMessage = '';

$email = $_SESSION['admin_email'] ?? '';

$currentPassword = ''; 
$password = '';
$confpassword = ''; 

if (isset($_SESSION['admin_email'])) {
    if (isset($_POST['submit'])) {
        $currentPassword = trim($_POST['current_password']);
        $password = trim($_POST['password']);
        $confpassword = trim($_POST['confpassword']);

        // Validate current password
        if (empty($currentPassword)) {
            $currentPasswordError = "Please enter your current password.";
        } else {
            // Fetch the current password hash from the database
            $stmt = $con->prepare("SELECT password FROM admin_info WHERE email = ?");
            $stmt->bind_param('s', $email);
            $stmt->execute();
            $stmt->bind_result($storedPassword);
            $stmt->fetch();
            $stmt->close();

            // Verify if the current password matches the stored hash
            if (!($currentPassword == $storedPassword)) {
                $currentPasswordError = "Current password is incorrect.";
            }
        }

        // Validate new password
        if (empty($password)) {
            $passwordError = "Please enter a new password.";
        } elseif (strlen($password) < 8 || !preg_match('/[A-Z]/', $password) || !preg_match('/\d/', $password) || !preg_match('/[!@#$%^&*()_+=\-{}[\]:;"\'<>,.?\/~`|]/', $password)) {
            $passwordError = "Password must be at least 8 characters long, contain an uppercase letter, a number, and a special character.";
        } elseif ($password === $currentPassword) {
            $passwordError = "New password cannot be the same as the current password.";
        } elseif (empty($confpassword)) {
            $confpasswordError = "Please confirm your password.";
        } elseif ($password !== $confpassword) {
            $confpasswordError = "Passwords do not match.";
        }

        // Proceed if no validation errors
        if (empty($currentPasswordError) && empty($passwordError) && empty($confpasswordError)) {
           
            
            // Update password
            $stmt = $con->prepare("UPDATE admin_info SET password = ? WHERE email = ?");
            $stmt->bind_param('ss', $password, $email);

            if ($stmt->execute()) {
                session_regenerate_id(true);
                $successMessage = "Password changed successfully.";
                header("Location: index.php?status=success");
                exit();
            } else {
                $password_error = "Error updating password.";
            }

            $stmt->close();
        }
    }
?>
<div id="page-wrapper">
        <div class="form-container">
            <h3 class="text-center pt-5">Change Password</h3>
            <form method="POST">
                <div class="form-group">
                    <label for="current_password" class="mb-2">Current Password</label>
                    <input type="password" class="form-control <?php echo $currentPasswordError ? 'is-invalid' : ''; ?>" name="current_password" placeholder="Enter Your Current Password" value="<?php echo htmlspecialchars($currentPassword); ?>">
                    <div class="invalid-feedback"><?php echo $currentPasswordError; ?></div>

                    <label for="password" class="mb-2 mt-3">Enter New Password</label>
                    <input type="password" class="form-control <?php echo $passwordError ? 'is-invalid' : ''; ?>" name="password" placeholder="Enter Your New Password" value="<?php echo htmlspecialchars($password); ?>">
                    <div class="invalid-feedback"><?php echo $passwordError; ?></div>

                    <label for="confpassword" class="mb-2 mt-3">Confirm Password</label>
                    <input type="password" class="form-control <?php echo $confpasswordError ? 'is-invalid' : ''; ?>" name="confpassword" placeholder="Enter Confirm Password" value="<?php echo htmlspecialchars($confpassword); ?>">
                    <div class="invalid-feedback"><?php echo $confpasswordError; ?></div>
                </div>
                <div class="form-group mt-3">
                    <input type="checkbox" id="show_password" onclick="togglePasswordVisibility()">
                    <label for="show_password">Show Passwords</label>
                </div>
                <p class="mt-3">Don't want to change password? <a href="index.php" class="backclass">Go Back</a></p>
                <div class="form-group text-center">
                <button type="submit" name="submit" class="btn btn-success btn-block mb-4">Submit</button>

                </div>
                <?php if ($password_error) echo "<div class='alert alert-danger'>$password_error</div>"; ?>
                <?php if ($successMessage) echo "<div class='alert alert-success'>$successMessage</div>"; ?>
            </form>
        </div>
    </div>
    <script>
        function togglePasswordVisibility() {
            const currentPasswordField = document.querySelector('input[name="current_password"]');
            const passwordField = document.querySelector('input[name="password"]');
            const confPasswordField = document.querySelector('input[name="confpassword"]');
            const showPasswordCheckbox = document.getElementById('show_password');

            const type = showPasswordCheckbox.checked ? 'text' : 'password';
            currentPasswordField.type = type;
            passwordField.type = type;
            confPasswordField.type = type;
        }
    </script>
    
<?php
}
?>
