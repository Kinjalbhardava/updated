<?php

$con = new mysqli("localhost", "root", "Mysql@123", "student");
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}


?>