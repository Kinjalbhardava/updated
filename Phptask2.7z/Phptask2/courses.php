<style>
    th {
        color: #337ab7;
    }

    .top_p {
        font-size: 24px;
        font-weight: bold;
        padding-top: 20px;
        padding-bottom: 10px;
        color: #337ab7;
    }

    th a { 
        text-decoration: none;
        color: #337ab7;
    }
</style>

<?php
session_start();
if (isset($_SESSION["admin_email"])) {

    include('conn.php');
    include('header.php');

    // Status messages

    $statusMessages = [
        'success' => "Your record has been inserted successfully!",
        'delete' => "Your record was deleted successfully!",
        'update' => "Data updated successfully!",
    ];

    // Pagination
    $search = isset($_GET['search']) ? $_GET['search'] : '';
    $sort_order = 'ASC';
    $order_by = 'id';
    $items_per_page = 5;
    $page = max((int) ($_GET['page'] ?? 1), 1);
    $offset = ($page - 1) * $items_per_page;

    if (isset($_GET['order_by']) && in_array($_GET['order_by'], ['id', 'title', 'description', 'duration'])) {
        $order_by = $_GET['order_by'];
    }
    if (isset($_GET['sort_order']) && in_array($_GET['sort_order'], ['ASC', 'DESC'])) {
        $sort_order = $_GET['sort_order'];
    }

    // Toggle sorting order for the next click

    $next_sort_order = $sort_order === 'ASC' ? 'DESC' : 'ASC';
    $icon = $sort_order === 'ASC' ? 'fa-sort-up' : 'fa-sort-down';



    // Count total records
    $countQuery = "SELECT COUNT(*) FROM courses" . ($search ? " WHERE title LIKE ? OR description LIKE ? OR duration LIKE ?" : "");
    $countStmt = $con->prepare($countQuery);

    if ($search) {
        $searchParam = "%$search%";
        // Correct the number of 's' in bind_param for all three fields
        $countStmt->bind_param('sss', $searchParam, $searchParam, $searchParam);
    }
    $countStmt->execute();
    $total = $countStmt->get_result()->fetch_row()[0];
    $total_pages = ceil($total / $items_per_page);

    // Fetch records with pagination
    $query = "SELECT * FROM courses " . ($search ? "WHERE title LIKE ? OR description LIKE ? OR duration LIKE ? " : "") . "ORDER BY $order_by $sort_order LIMIT ?, ?";
    $stmt = $con->prepare($query);

    if ($search) {
        // Bind parameters correctly for both search and pagination
        $stmt->bind_param('sssii', $searchParam, $searchParam, $searchParam, $offset, $items_per_page);
    } else {
        $stmt->bind_param('ii', $offset, $items_per_page);
    }

    $stmt->execute();
    $result = $stmt->get_result();
    ?>
    <div id="page-wrapper">
        <p class="text-center top_p">Course Details</p>
        <?php

        // Status messages
        $statusMessages = [
            'success' => "Your record has been inserted successfully!",
            'update' => "Data updated successfully!",
            'delete' => "Your record was deleted successfully!"
        ];

        // Display status message if exists
        if (isset($_GET['status']) && array_key_exists($_GET['status'], $statusMessages)) {
            echo "<div class='alert alert-success alert-dismissible fade show' role='alert'>"
                . $statusMessages[$_GET['status']]
                . "<button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>"
                . "</div>";
        }
        ?>
        <form method="get" class="row mb-3 mt-0">
            <div class="row">
                <div class="col col-lg-7"></div>
                <div class="col col-lg-3 flex-end">
                    <input class="form-control" type="search" name="search" value="<?php echo htmlspecialchars($search); ?>"
                        placeholder="Search" aria-label="Search">
                </div>
                <div class="col-auto">
                    <button type="submit" class="btn btn-success mb-3">Search</button>
                </div>
                <div class="col col-lg-5"></div>
            </div>
        </form>


        <table class="table table-striped mt-0 pt-0">
            <thead>
                <tr>
                    <th><a
                            href="?page=<?php echo $page; ?>&search=<?php echo urlencode($search); ?>&order_by=id&sort_order=<?php echo $next_sort_order; ?>">Course
                            ID <i class="fas <?php echo ($order_by === 'id') ? $icon : 'fa-sort'; ?>"></i></a></th>
                    <th><a
                            href="?page=<?php echo $page; ?>&search=<?php echo urlencode($search); ?>&order_by=title&sort_order=<?php echo $next_sort_order; ?>">Course
                            Title <i class="fas <?php echo ($order_by === 'title') ? $icon : 'fa-sort'; ?>"></i></a></th>
                    <th><a
                            href="?page=<?php echo $page; ?>&search=<?php echo urlencode($search); ?>&order_by=description&sort_order=<?php echo $next_sort_order; ?>">Description
                            <i class="fas <?php echo ($order_by === 'description') ? $icon : 'fa-sort'; ?>"></i></a></th>
                    <th><a
                            href="?page=<?php echo $page; ?>&search=<?php echo urlencode($search); ?>&order_by=duration&sort_order=<?php echo $next_sort_order; ?>">Duration
                            <i class="fas <?php echo ($order_by === 'duration') ? $icon : 'fa-sort'; ?>"></i></a></th>
                    <th>User Enroll Count </th>
                    <th>Edit </th>
                    <th>Delete </th>
                </tr>
            </thead>
            <tbody>
                <?php
                // user enrollment count of per courses 
                $stmtuser = $con->prepare("SELECT COUNT(enrollments.user_id) AS user_count FROM enrollments WHERE course_id = ?");

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $stmtuser->bind_param('i', $row['id']);
                        $stmtuser->execute();
                        $courseResult = $stmtuser->get_result();
                        $courseRow = $courseResult->fetch_assoc();
                        $user_count = $courseRow['user_count'] ?? 0;

                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($row['id']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['title']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['description']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['duration']) . "</td>";
                        echo "<td>" . htmlspecialchars($user_count) . "</td>";
                        echo "<td><a href='newcourse.php?id=" . htmlspecialchars($row['id']) . "' class='btn btn-primary'>Edit</a></td>";
                        echo "<td><a href='#' class='btn btn-danger' data-bs-toggle='modal' data-bs-target='#deleteModal' onclick='setDeleteId(" . htmlspecialchars($row['id']) . ")'>Delete</a></td>";
                        echo "</tr>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='6'>No results found.</td></tr>";
                }

                $stmt->close();
                ?>
            </tbody>
        </table>

        <!-- Delete Confirmation Modal -->
        <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="deleteModalLabel">Confirm Deletion</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        Are you sure you want to delete this Course?
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <a id="confirmDelete" class="btn btn-danger">Delete</a>
                    </div>
                </div>
            </div>
        </div>

        <script>
            function setDeleteId(id) {
                const deleteLink = document.getElementById('confirmDelete');
                deleteLink.href = 'courseDelete.php?id=' + id;
            }
        </script>

        <!-- Pagination -->
        <nav aria-label="Page navigation">
            <ul class="pagination justify-content-center">
                <?php if ($page > 1): ?>
                    <li class="page-item">
                        <a class="page-link"
                            href="?page=<?php echo $page - 1; ?>&search=<?php echo urlencode($search); ?>&order_by=<?php echo $order_by; ?>&sort_order=<?php echo $sort_order; ?>"
                            aria-label="Previous">
                            <span aria-hidden="true">&laquo;</span>
                        </a>
                    </li>
                <?php else: ?>
                    <li class="page-item disabled">
                        <span class="page-link" aria-label="Previous">&laquo;</span>
                    </li>
                <?php endif; ?>

                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <li class="page-item <?php echo ($i === $page) ? 'active' : ''; ?>">
                        <a class="page-link"
                            href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&order_by=<?php echo $order_by; ?>&sort_order=<?php echo $sort_order; ?>"><?php echo $i; ?></a>
                    </li>
                <?php endfor; ?>

                <?php if ($page < $total_pages): ?>
                    <li class="page-item">
                        <a class="page-link"
                            href="?page=<?php echo $page + 1; ?>&search=<?php echo urlencode($search); ?>&order_by=<?php echo $order_by; ?>&sort_order=<?php echo $sort_order; ?>"
                            aria-label="Next">
                            <span aria-hidden="true">&raquo;</span>
                        </a>
                    </li>
                <?php else: ?>
                    <li class="page-item disabled">
                        <span class="page-link" aria-label="Next">&raquo;</span>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>
    </div>

    <?php
    include("footer.php");


} else {
    // Redirect to login if not authenticated
    header("Location: login.php");
    exit();
}
?>