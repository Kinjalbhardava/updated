<style>
    .top_p {
        font-size: 24px;
        font-weight: bold;
        padding-top: 20px;
        padding-bottom: 10px;
        color: #337ab7;
    }

    th {
        color: #337ab7;
    }

    th a {
        text-decoration: none;
        color: #337ab7;
    }
</style>

<?php
session_start();
if (isset($_SESSION["admin_email"])) {
    include('conn.php');
    include('header.php');

    // Status messages
    $statusMessages = [
        'success' => "Your record has been inserted successfully!",
        'update' => "Data updated successfully!",
        'delete' => "Your record was deleted successfully!"
    ];
    
    // Get parameters
    
    $search = filter_input(INPUT_GET, 'search', FILTER_SANITIZE_STRING);
    $user_id = filter_input(INPUT_GET, 'user_id', FILTER_VALIDATE_INT);
    $course_id = filter_input(INPUT_GET, 'course_id', FILTER_VALIDATE_INT);
    
    $filter_course = isset($_GET['filter']);
    $filter = isset($_GET['filter']);
    $search_btn = isset($_GET['search_btn']);

    $query_conditions = [];
    $params = [];
    $types = '';

    $sort_order = 'ASC';
    $order_by = 'enrollment_id';
    $items_per_page = 5;
    $page = max((int) ($_GET['page'] ?? 1), 1);
    $offset = ($page - 1) * $items_per_page;

    // Validate sorting parameters
    if (isset($_GET['order_by']) && in_array($_GET['order_by'], ['enrollment_id', 'username', 'coursename', 'date'])) {
        $order_by = $_GET['order_by'];
    }
    if (isset($_GET['sort_order']) && in_array($_GET['sort_order'], ['ASC', 'DESC'])) {
        $sort_order = $_GET['sort_order'];
    }

    // Toggle sorting order for the next click
    $next_sort_order = $sort_order === 'ASC' ? 'DESC' : 'ASC';
    $icon = $sort_order === 'ASC' ? 'fa-sort-up' : 'fa-sort-down';

    // Search logic
    if ($search) {
        $query_conditions[] = "(user.name LIKE ? OR courses.title LIKE ? OR enrollments.enrollment_date LIKE ?)";
        $search_param = "%$search%";
        $params[] = $search_param;
        $params[] = $search_param;
        $params[] = $search_param;
        $types .= 'sss';
    }

    // User filter logic
    if ($user_id) {
        $query_conditions[] = "enrollments.user_id = ?";
        $params[] = (int) $user_id;
        $types .= 'i';
    }
    if ($course_id) {
        $query_conditions[] = "enrollments.course_id = ?";
        $params[] = (int) $course_id;
        $types .= 'i';
    }
    $where_clause = '';
    if (count($query_conditions) > 0) {
        $where_clause = ' WHERE ' . implode(' AND ', $query_conditions);
    }

    // Count total records query
    $countQuery = "SELECT COUNT(*) 
                   FROM enrollments
                   JOIN user ON enrollments.user_id = user.id
                   JOIN courses ON enrollments.course_id = courses.id" . $where_clause;

    $countStmt = $con->prepare($countQuery);
    if ($params) {
        $countStmt->bind_param($types, ...$params);
    }
    $countStmt->execute();
    $total = $countStmt->get_result()->fetch_row()[0];
    $total_pages = ceil($total / $items_per_page);

    // Final SQL query for records
    $query = "SELECT enrollments.id AS enrollment_id, user.name AS username, courses.title AS coursename, enrollments.enrollment_date AS date 
              FROM enrollments
              JOIN user ON enrollments.user_id = user.id
              JOIN courses ON enrollments.course_id = courses.id" . $where_clause .
        " ORDER BY $order_by $sort_order LIMIT ? OFFSET ?";

    // Prepare statement for fetching records
    $stmt = $con->prepare($query);
    if ($params) {
        $params[] = $items_per_page;
        $params[] = $offset;
        $stmt->bind_param($types . 'ii', ...$params);
    } else {
        $stmt->bind_param('ii', $items_per_page, $offset);
    }

    $stmt->execute();
    $result = $stmt->get_result();
    ?>


    <div id="page-wrapper">
        <p class="text-center top_p">Enrollments Details</p>

        <?php
        if (isset($_GET['status']) && array_key_exists($_GET['status'], $statusMessages)) {
            echo "<div class='alert alert-success alert-dismissible fade show' role='alert'>"
                . $statusMessages[$_GET['status']]
                . "<button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>"
                . "</div>";
        }
        ?>
        <form method="get" class="row mb-3 mt-0">
            <div class="row align-items-end">
                <div class="col col-lg-2">
                    <span>Filter User:</span>
                    <select id="user_id" name="user_id" class="form-control">
                        <option value="">Select User</option>
                        <?php
                        // Fetch users from the database
                        $userStmt = $con->prepare("SELECT id, name FROM user");
                        $userStmt->execute();
                        $userResult = $userStmt->get_result();
                        while ($user = $userResult->fetch_assoc()) {
                            $selected = (isset($_GET['user_id']) && $_GET['user_id'] == $user['id']) ? 'selected' : '';
                            echo "<option value='" . htmlspecialchars($user['id']) . "' $selected>" . htmlspecialchars($user['name']) . "</option>";
                        }
                        $userStmt->close();
                        ?>
                    </select>
                </div>
                <div class="col-auto">
                    <button type="submit" name="filter" class="btn btn-success">Filter</button>
                </div>

                <div class="col col-lg-2">
                    <span>Filter Course:</span>
                    <select id="course_id" name="course_id" class="form-control">
                        <option value="">Select Course</option>
                        <?php
                        $courseStmt = $con->prepare("SELECT id, title FROM courses");
                        $courseStmt->execute();
                        $courseResult = $courseStmt->get_result();
                        while ($course = $courseResult->fetch_assoc()) {
                            $selected = (isset($_GET['course_id']) && $_GET['course_id'] == $course['id']) ? 'selected' : '';
                            echo "<option value='" . htmlspecialchars($course['id']) . "' $selected>" . htmlspecialchars($course['title']) . "</option>";
                        }
                        $courseStmt->close();
                        ?>
                    </select>
                </div>
                <div class="col-auto">
                    <button type="submit" name="filter_course" class="btn btn-success">Filter</button>
                </div>

                <div class="col col-lg-3 flex-end">
                    <input class="form-control" type="search" name="search" value="<?php echo htmlspecialchars($search); ?>"
                        placeholder="Search" aria-label="Search">
                </div>
                <div class="col-auto">
                    <button type="submit" name="search_btn" class="btn btn-success">Search</button>
                </div>
            </div>
        </form>



        <table class="table table-striped mt-0 pt-0">
            <thead>
                <tr>
                    <th>
                        <a
                            href="?page=<?php echo $page; ?>&search=<?php echo urlencode($search); ?>&user_id=<?php echo $user_id; ?>&course_id=<?php echo $course_id; ?> &order_by=enrollment_id&sort_order=<?php echo $next_sort_order; ?>">
                            Enrollment ID <i class="fas <?php echo ($order_by === 'enrollment_id') ? $icon : 'fa-sort'; ?>"></i>
                        </a>
                    </th>
                    <th>
                        <a
                            href="?page=<?php echo $page; ?>&search=<?php echo urlencode($search); ?>&course_id=<?php echo $course_id; ?>&user_id=<?php echo $user_id; ?>&order_by=username&sort_order=<?php echo $next_sort_order; ?>">
                            User Name <i class="fas <?php echo ($order_by === 'username') ? $icon : 'fa-sort'; ?>"></i>
                        </a>
                    </th>
                    <th>
                        <a
                            href="?page=<?php echo $page; ?>&search=<?php echo urlencode($search); ?>&user_id=<?php echo $user_id; ?>&course_id=<?php echo $course_id; ?>&order_by=coursename&sort_order=<?php echo $next_sort_order; ?>">
                            Course Name <i class="fas <?php echo ($order_by === 'coursename') ? $icon : 'fa-sort'; ?>"></i>
                        </a>
                    </th>
                    <th>
                        <a
                            href="?page=<?php echo $page; ?>&search=<?php echo urlencode($search); ?>&user_id=<?php echo $user_id; ?>&course_id=<?php echo $course_id; ?>&order_by=date&sort_order=<?php echo $next_sort_order; ?>">
                            Enrollment Date <i class="fas <?php echo ($order_by === 'date') ? $icon : 'fa-sort'; ?>"></i>
                        </a>
                    </th>
                    <th>Edit</th>
                    <th>Delete</th>
                </tr>
            </thead>

            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($row['enrollment_id']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['username']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['coursename']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['date']) . "</td>";
                        echo "<td><a href='newenrollment.php?id=" . htmlspecialchars($row['enrollment_id']) . "' class='btn btn-primary'>Edit</a></td>";
                        echo "<td><a href='#' class='btn btn-danger' data-bs-toggle='modal' data-bs-target='#deleteModal' onclick='setDeleteId(" . htmlspecialchars($row['enrollment_id']) . ")'>Delete</a></td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='6'>No results found.</td></tr>";
                }

                $stmt->close();
                ?>
            </tbody>
        </table>

        <!-- Delete Confirmation Modal -->
        <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="deleteModalLabel">Confirm Deletion</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        Are you sure you want to delete this enrollment?
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <a id="confirmDelete" class="btn btn-danger">Delete</a>
                    </div>
                </div>
            </div>
        </div>

        <script>
            function setDeleteId(id) {
                const deleteLink = document.getElementById('confirmDelete');
                deleteLink.href = 'enrollmentDelete.php?id=' + id;
            }
        </script>

        <!-- pagination -->

        <nav aria-label="Page navigation">
            <ul class="pagination justify-content-center">
                <?php if ($page > 1): ?>
                    <li class="page-item">
                        <a class="page-link"
                            href="?page=<?php echo $page - 1; ?>&search=<?php echo urlencode($search); ?>&user_id=<?php echo $user_id; ?>&course_id=<?php echo $course_id; ?>&order_by=<?php echo $order_by; ?>&sort_order=<?php echo $sort_order; ?>"
                            aria-label="Previous">
                            <span aria-hidden="true">&laquo;</span>
                        </a>
                    </li>
                <?php endif; ?>

                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <li class="page-item <?php echo ($i === $page) ? 'active' : ''; ?>">
                        <a class="page-link"
                            href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&user_id=<?php echo $user_id; ?>&course_id=<?php echo $course_id; ?>&order_by=<?php echo $order_by; ?>&sort_order=<?php echo $sort_order; ?>"
                            <?php echo ($i === $page) ? 'aria-current="page"' : ''; ?>>
                            <?php echo $i; ?>
                        </a>
                    </li>
                <?php endfor; ?>

                <?php if ($page < $total_pages): ?>
                    <li class="page-item">
                        <a class="page-link"
                            href="?page=<?php echo $page + 1; ?>&search=<?php echo urlencode($search); ?>&user_id=<?php echo $user_id; ?>&course_id=<?php echo $course_id; ?>&order_by=<?php echo $order_by; ?>&sort_order=<?php echo $sort_order; ?>"
                            aria-label="Next">
                            <span aria-hidden="true">&raquo;</span>
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>

    </div>

    <?php
    include("footer.php");
} else {
    // Redirect to login if not authenticated
    header("Location: login.php");
    exit();
}
?>