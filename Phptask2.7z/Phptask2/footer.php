<style>
    .footer1{
        color:#337ab7;
        margin-left: 550px;
    }
</style>
<!-- <div id="page-wrapper"> -->
<footer class="footer1">
    All Rights Reserved, &copy;Copyright by Comapny, 2024.
</footer></div>