<?php
session_start();
if (isset($_SESSION["admin_email"])) {
    ?>

    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="Administrator Dashboard">
        <title>Administrator</title>

        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="assets/css/sb-admin-2.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
        <style>
            body {
                background-color: #f8f9fa;
            }

            .navbar {
                background-color: #337ab7;
            }

            .navbar-brand,
            .navbar-nav .nav-link {
                color: white;
            }

            .sidebar {
                height: 100vh;
                padding-top: 20px;
                background-color: white;
                border-right: 1px solid #dee2e6;
            }

            .nav-link {
                color: #337ab7;
            }

            .nav-link:hover {
                background-color: #337ab7;
                color: white;
            }

            .hidden {
                display: none;
            }

            .submenu {
                padding-left: 15px;
                font-size: 14px;
                background-color: #f8f9fa;
                border-left: 3px solid #337ab7;
                list-style-type: none;
            }

            .submenu a:hover {
                background-color: #e9ecef;
                color: #337ab7;
            }

            .adminname {
                color: #337ab7;
            }
        </style>
    </head>

    <body>
        <div id="wrapper">
            <header>
                <nav class="navbar navbar-expand-lg navbar-dark">
                    <div class="container-fluid">
                        <a class="navbar-brand" href="#">Administrator</a>
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarNav">
                            <ul class="navbar-nav ms-auto">
                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" id="userDropdown" role="button"
                                        data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="fa fa-user fa-fw"></i>
                                    </a>
                                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                                        <p class="text-center adminname"><?php echo ($_SESSION['admin_email']); ?></p>
                                        <div class="dropdown-divider"></div>
                                        <li><a class="dropdown-item" href="change_password.php"><i
                                                    class="fa fa-user fa-fw pe-4"></i> Change
                                                Password</a></li>
                                        <li><a class="dropdown-item" href="logout.php"><i
                                                    class="fa fa-power-off fa-fw pe-4"></i>
                                                Logout</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div>
                </nav>
            </header>

            <aside class="sidebar navbar-default mt-0">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav flex-column" id="side-menu">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php"><i class="fa fa-cogs me-2 fa-fw"></i> Dashboard</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" onclick="toggleDropdown('userSubMenu', this)" aria-expanded="false"
                                aria-haspopup="true">
                                <i class="fa fa-users me-2 fa-fw"></i> Users <i class="fa fa-caret-down float-end"></i>
                            </a>
                            <ul id="userSubMenu" class="submenu hidden">
                                <li><a class="nav-link" href="users.php"><i class="fa fa-list me-2 fa-fw"></i> User
                                        Listing</a></li>
                                <li><a class="nav-link" href="newuser.php"><i class="fa fa-plus me-2 fa-fw"></i> Add New</a>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" onclick="toggleDropdown('courseSubMenu', this)"
                                aria-expanded="false" aria-haspopup="true">
                                <i class="fa fa-book me-2 fa-fw"></i> Courses <i class="fa fa-caret-down float-end"></i>
                            </a>
                            <ul id="courseSubMenu" class="submenu hidden">
                                <li><a class="nav-link" href="courses.php"><i class="fa fa-list me-2 fa-fw"></i> Course
                                        Listing</a></li>
                                <li><a class="nav-link" href="newcourse.php"><i class="fa fa-plus me-2 fa-fw"></i> Add
                                        New</a></li>
                            </ul>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" onclick="toggleDropdown('enrollmentSubMenu', this)"
                                aria-expanded="false" aria-haspopup="true">
                                <i class="fa fa-address-book me-2 fa-fw"></i> Enrollments <i
                                    class="fa fa-caret-down float-end"></i>
                            </a>
                            <ul id="enrollmentSubMenu" class="submenu hidden">
                                <li><a class="nav-link" href="enrollment.php"><i class="fa fa-list me-2 fa-fw"></i>
                                        Enrollments Listing</a></li>
                                <li><a class="nav-link" href="newenrollment.php"><i class="fa fa-plus me-2 fa-fw"></i> Add
                                        New</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </aside>

        </div>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p"
            crossorigin="anonymous"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
       
       <!-- js for slider dropdown listing -->
       <script>
            function toggleDropdown(submenuId, element) {
                const submenu = document.getElementById(submenuId);
                const isExpanded = element.getAttribute('aria-expanded') === 'true';

                submenu.classList.toggle('hidden');

                element.setAttribute('aria-expanded', !isExpanded);
            }

        </script>
    </body>

    </html>

    <?php
} else {
    // Redirect to login if not authenticated
    header("Location: login.php");
    exit();
}
?>
