<style>
    a span {
        color: #337ab7;
    }

    .fa-arrow-circle-right:before {
        color: #337ab7;
    }

    .row .card {
        background-color: #337ab7;
    }
</style>

<?php
session_start();
if (isset($_SESSION["admin_email"])) {
    include_once("header.php");
    include_once("conn.php");


  
    // Get total count of users, courses, and enrollments
    $userCount = 0;
    $courseCount = 0;
    $enrollmentCount = 0;

    // Get user count
    $stmt = $con->prepare("SELECT COUNT(*) as user_count FROM user");
    if ($stmt) {
        $stmt->execute();
        $res = $stmt->get_result();
        $row = $res->fetch_assoc();
        $userCount = (int)$row['user_count'];
        $stmt->close();
    }

    // Get course count
    $stmt = $con->prepare("SELECT COUNT(*) as course_count FROM courses");
    if ($stmt) {
        $stmt->execute();
        $res2 = $stmt->get_result();
        $row2 = $res2->fetch_assoc();
        $courseCount = (int)$row2['course_count'];
        $stmt->close();
    }

    // Get enrollment count
    $stmt = $con->prepare("SELECT COUNT(*) as enrollment_count FROM enrollments");
    if ($stmt) {
        $stmt->execute();
        $res3 = $stmt->get_result();
        $row3 = $res3->fetch_assoc();
        $enrollmentCount = (int)$row3['enrollment_count'];
        $stmt->close();
    }
?>
<div id="page-wrapper">
  
    <div class="row">
        <div class="col-lg-12">
        </div>
    </div>
    <div class="row mt-4">

    <?php

     $statusMessages = [
        'success' => "Your password has been changed successfully!",
        'login' => "Welcome, to the Admin Panel   !!",
   
    ];

    // Display status message if exists
    if (isset($_GET['status']) && array_key_exists($_GET['status'], $statusMessages)) {
        echo "<div class='alert alert-success alert-dismissible fade show' role='alert'>"
            . $statusMessages[$_GET['status']]
            . "<button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>"
            . "</div>";
    }
    
?>

        <div class="col-lg-4 col-md-6">
            <div class="card text-white mb-4">
                <div class="card-body d-flex align-items-center">
                    <i class="fa fa-user fa-5x me-3"></i>
                    <div>
                        <h5>Users</h5>
                        <h2><?php echo htmlspecialchars($userCount); ?></h2>
                    </div>
                </div>
                <a href="users.php" class="card-footer text-white bg-light text-decoration-none d-flex justify-content-between align-items-center">
                    <span>View Details</span>
                    <i class="fa fa-arrow-circle-right"></i>
                </a>
            </div>
        </div>

        <div class="col-lg-4 col-md-6">
            <div class="card text-white mb-4">
                <div class="card-body d-flex align-items-center">
                    <i class="fa fa-tasks fa-5x me-3"></i>
                    <div>
                        <h5>Courses</h5>
                        <h2><?php echo htmlspecialchars($courseCount); ?></h2>
                    </div>
                </div>
                <a href="courses.php" class="card-footer text-white bg-light text-decoration-none d-flex justify-content-between align-items-center">
                    <span>View Details</span>
                    <i class="fa fa-arrow-circle-right"></i>
                </a>
            </div>
        </div>

        <div class="col-lg-4 col-md-6">
            <div class="card text-white mb-4">
                <div class="card-body d-flex align-items-center">
                    <i class="fa fa-address-book fa-5x me-3"></i>
                    <div>
                        <h5>Enrollments</h5>
                        <h2><?php echo htmlspecialchars($enrollmentCount); ?></h2>
                    </div>
                </div>
                <a href="enrollment.php" class="card-footer text-white bg-light text-decoration-none d-flex justify-content-between align-items-center">
                    <span>View Details</span>
                    <i class="fa fa-arrow-circle-right"></i>
                </a>
            </div>
        </div>
    </div>
</div>

<?php 
} else {
    // Redirect to login if not authenticated
    header("Location: login.php");
    exit();

}

include("footer.php");

?>
