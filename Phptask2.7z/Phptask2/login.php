<?php
session_start();

include("conn.php");

$emailEmpty = '';
$passwordEmpty = '';
$passwordError = '';

// Check if the user is already logged in
if (isset($_SESSION['admin_email'])) {
    header("Location: index.php");
    exit();
}

if (isset($_POST['submit'])) {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    if (empty($email)) {
        $emailEmpty = "Please Enter Email";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $emailEmpty = "Please enter a valid email address.";
    }

    if (empty($password)) {
        $passwordEmpty = "Please Enter Password";
    }
    
    // Proceed only if no validation errors
    
    if (empty($emailEmpty) && empty($passwordEmpty)) {
        $stmt = $con->prepare("SELECT * FROM admin_info WHERE email = ?");
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($row = $result->fetch_assoc()) {
            // Use password_verify() to check the password
            if (($password === $row['password'])) {
                session_regenerate_id(true);
                $_SESSION['admin_email'] = $email; 
                header("Location: index.php?status=login"); 
                exit();
            } else {
                $passwordError = "Invalid credentials";
            }
        } else {
            $passwordError = "Invalid credentials";
        }

        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin User</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            max-width: 600px;
            margin-top: 50px;
        }
        .form-container {
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            background-color: #ffffff;
        }
        .form-header {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="container">
                <div class="form-container">
                    <h2 class="form-header text-center">Admin Login</h2>
                    <form method="POST">
                        <div class="form-group">
                            <label for="email" class="mb-2">Enter Email</label><br>
                            <input type="text" class="form-control <?php echo $emailEmpty ? 'is-invalid' : ''; ?>" name="email" placeholder="Enter Your Email" value="<?php echo htmlspecialchars($email ?? '', ENT_QUOTES); ?>">
                            <div class="invalid-feedback"><?php echo $emailEmpty; ?></div>

                            <label for="password" class="mb-2 mt-3">Enter Password</label><br>
                            <input type="password" class="form-control <?php echo $passwordEmpty || $passwordError ? 'is-invalid' : ''; ?>" name="password" placeholder="Enter Your Password">
                            <div class="invalid-feedback"><?php echo $passwordEmpty ? $passwordEmpty : $passwordError; ?></div>
                        </div>
                        <button type="submit" name="submit" class="btn btn-primary btn-block mb-4 mt-4">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
