<?php
session_start();
session_destroy();

// redirect to the admin login page

header("Location: login.php");


?>