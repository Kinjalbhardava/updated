<style>
    h2{
        color: #337ab7;
    }
    .backclass{
        text-decoration: none;
        color: #337ab7;
    }
</style>
<?php
ob_start();
session_start();
if (isset($_SESSION["admin_email"])) {
    include("conn.php");
    include("header.php");

    $title = '';
    $description = '';
    $duration = '';
    $id = null;
    $titleError = '';
    $descriptionError = '';
    $durationError = '';
    $existsError = '';
    $coursename_error = '';
    $duration_limit_error = '';

    // Fetch course data if ID is provided
    if (isset($_GET['id'])) {
        $id = (int) $_GET['id'];
        $stmt = $con->prepare("SELECT title, description, duration FROM courses WHERE id = ?");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($row = $result->fetch_assoc()) {
            $title = $row['title'];
            $description = $row['description'];
            $duration = $row['duration'];
        }
    }

    // Handle form submission
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {

        $title = trim($_POST['title']);
        $description = trim($_POST['description']);
        $duration = trim($_POST['duration']);

        // Validation for title
        if (empty($title)) {
            $titleError = "Please enter course title.";
        } elseif (!preg_match('/^[a-zA-Z\s]+$/', $title)) {
            $titleError = "Please enter a valid title.";
        }
        // Validation for description
        if (empty($description)) {
            $descriptionError = "Please enter course description.";
        }
        // Validation for duration
        if (empty($duration)) {
            $durationError = "Please enter your course duration.";
        } elseif (!is_numeric($duration) || $duration < 1 || $duration > 24) {
            $durationError = "Please enter a valid duration (between 1 and 24 months).";
        }

        // Proceed only if no validation errors
        if (empty($titleError) && empty($descriptionError) && empty($durationError)) {
            // Check for existing course
            $stmt = $con->prepare("SELECT * FROM courses WHERE title = ?" . ($id ? " AND id != ?" : ""));
            if ($id) {
                $stmt->bind_param("si", $title, $id);
            } else {
                $stmt->bind_param('s', $title);
            }
            if ($stmt->execute()) {
                $result = $stmt->get_result();

                if ($result->num_rows > 0) {
                    $coursename_error = "This course is already registered. Please use a different one.";
                } else {
                    // Prepare insert or update statement
                    if ($id) {
                        $stmt = $con->prepare("UPDATE courses SET title = ?, description = ?, duration = ? WHERE id = ?");
                        $stmt->bind_param('sssi', $title, $description, $duration, $id);
                    } else {
                        $stmt = $con->prepare("INSERT INTO courses (title, description, duration) VALUES (?, ?, ?)");
                        $stmt->bind_param('sss', $title, $description, $duration);
                    }

                    // Execute the statement
                    if ($stmt->execute()) {
                        header("Location: courses.php?status=" . ($id ? 'update' : 'success'));
                        exit();
                    } else {
                        error_log("Database error: " . $stmt->error);
                        $existsError = "An error occurred. Please try again.";
                    }
                }
            } else {
                error_log("" . $stmt->error);
            }
            $stmt->close();
        }

    }
    ?>

    <form method="POST">
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12" style="margin-top:40px;">
                    <h2 class="form-header text-center"><?php echo ($id) ? 'Update Course' : 'Add Course'; ?></h2>

                    <div class="form-group">
                        <label for="title" class="mb-2">Title</label>
                        <input type="text" name="title" value="<?php echo htmlspecialchars($title, ENT_QUOTES, 'UTF-8'); ?>"
                            placeholder="Please enter course title" class="form-control" id="title">
                    </div>
                    <div class="text-danger"><?php echo $titleError; ?></div>
                    <div class="text-danger"><?php echo $coursename_error; ?></div>

                    <div class="form-group">
                        <label for="description" class="mb-2 mt-2">Description</label>
                        <input type="text" name="description"
                            value="<?php echo htmlspecialchars($description, ENT_QUOTES, 'UTF-8'); ?>"
                            placeholder="Please enter course description" class="form-control" id="description">
                    </div>
                    <div class="text-danger"><?php echo $descriptionError; ?></div>

                    <div class="form-group">
                        <label for="duration" class="mt-2">Duration</label>
                        <input name="duration" value="<?php echo htmlspecialchars($duration, ENT_QUOTES, 'UTF-8'); ?>"
                            placeholder="Please enter course duration" class="form-control mb-2 mt-2" type="text"
                            id="duration">
                    </div>
                    <div class="text-danger"><?php echo $durationError; ?></div>

                    <p class="mt-4">Don't want to add Course? <a href="courses.php" class="backclass">Go Back</a></p>
                    <div class="form-group text-center">
                        <button type="submit" class="btn btn-success">Submit</button>
                    </div>

                    <!-- Display any errors -->

                    <div class="text-danger"><?php echo $existsError; ?></div>



                    <div class="text-danger"><?php echo $existsError; ?></div>

                </div>
            </div>
        </div>
    </form>

    <?php include("footer.php");


} else {
    // Redirect to login if not authenticated
    header("Location: login.php");
    exit();
}
?>