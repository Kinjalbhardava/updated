<style>
    h2 {
        color: #337ab7;
    }

    th a {
        text-decoration: none;
        color: #337ab7;
    }

    .backclass {
        text-decoration: none;
        color: #337ab7;
    }
</style>

<?php
ob_start();
session_start();
if (!isset($_SESSION["admin_email"])) {
    header("Location: login.php");
    exit();
}

include("conn.php");
include("header.php");

$name = '';
$id = isset($_GET['id']) ? (int) $_GET['id'] : '';
$user_id = '';
$course_id = '';
$enrollment_date = '';
$record_existing_error = '';
$errors = [];

// Fetch existing enrollment data for update
if ($id) {
    $stmt = $con->prepare("
        SELECT enrollments.id, user.name, courses.title, enrollments.enrollment_date, enrollments.user_id, enrollments.course_id 
        FROM enrollments 
        JOIN user ON user.id = enrollments.user_id 
        JOIN courses ON courses.id = enrollments.course_id 
        WHERE enrollments.id = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        $user_id = $row['user_id'];
        $course_id = $row['course_id'];
        $enrollment_date = $row['enrollment_date'];
    }
    $stmt->close();
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = (int) $_POST['user_id'];
    $course_id = (int) $_POST['course_id'];
    $enrollment_date = $_POST['enrollment_date'];

    // Validation
    if (empty($user_id)) {
        $errors['user'] = "Please select a user.";
    }
    if (empty($course_id)) {
        $errors['course'] = "Please select a course.";
    }
    if (empty($enrollment_date)) {
        $errors['enrollment_date'] = "Please select an enrollment date.";
    } elseif (strtotime($enrollment_date) < time()) {
        $errors['enrollment_date'] = "Enrollment date must be today or a future date.";
    }

    // Proceed if all validations are passed
    if (empty($errors)) {
        // Check if the user is already enrolled in the course
        $stmt = $con->prepare("
            SELECT COUNT(*) FROM enrollments 
            WHERE user_id = ? AND course_id = ?
            " . ($id ? "AND id != ?" : ""));
        if ($id) {
            $stmt->bind_param('iii', $user_id, $course_id, $id);
        } else {
            $stmt->bind_param('ii', $user_id, $course_id);
        }
        $stmt->execute();
        $stmt->bind_result($exists);
        $stmt->fetch();
        $stmt->close();

        if ($exists) {
            $errors['user'] = "The user is already enrolled in this course.";
        } else {
            // Insert or update enrollment
            if ($id) {
                $stmt = $con->prepare("UPDATE enrollments SET user_id = ?, course_id = ?, enrollment_date = ? WHERE id = ?");
                $stmt->bind_param('iisi', $user_id, $course_id, $enrollment_date, $id);
            } else {
                $stmt = $con->prepare("INSERT INTO enrollments (user_id, course_id, enrollment_date) VALUES (?, ?, ?)");
                $stmt->bind_param('iis', $user_id, $course_id, $enrollment_date);
            }

            if ($stmt->execute()) {
                header("Location: enrollment.php?status=" . ($id ? "update" : "success"));
                exit();
            } else {
                $errors['db'] = "Database error: " . $stmt->error;
            }
        }
    }
}
?>
<div id="page-wrapper">
    <div class="form-container">
        <h2 class="text-center pt-5"><?php echo $id ? 'Update Enrollment' : 'Add Enrollment'; ?></h2>
        <form method="POST" novalidate>
            <div class="form-group">
                <label for="user_id" class="mb-2 mt-2">Select User</label>
                <select id="user_id" name="user_id"
                    class="form-control <?php echo isset($errors['user']) ? 'is-invalid' : ''; ?>">
                    <option value="">Select User</option>
                    <?php
                    $stmt = $con->prepare("SELECT id, name FROM user");
                    $stmt->execute();
                    $result = $stmt->get_result();

                    while ($row = $result->fetch_assoc()) {
                        $selected = ($row['id'] == $user_id) ? 'selected' : '';
                        echo "<option value=\"{$row['id']}\" $selected>" . htmlspecialchars($row['name']) . "</option>";
                    }
                    $stmt->close();
                    ?>
                </select>
                <div class="invalid-feedback">
                    <?php echo isset($errors['user']) ? htmlspecialchars($errors['user']) : ''; ?>
                </div>
            </div>

            <div class="form-group">
                <label for="course_id" class="mb-2 mt-2">Select Course</label>
                <select id="course_id" name="course_id"
                    class="form-control <?php echo isset($errors['course']) ? 'is-invalid' : ''; ?>">
                    <option value="">Select Course</option>
                    <?php
                    $stmt = $con->prepare("SELECT id, title FROM courses");
                    $stmt->execute();
                    $result = $stmt->get_result();

                    while ($row = $result->fetch_assoc()) {
                        $selected = ($row['id'] == $course_id) ? 'selected' : '';
                        echo "<option value=\"{$row['id']}\" $selected>" . htmlspecialchars($row['title']) . "</option>";
                    }
                    $stmt->close();
                    ?>
                </select>
                <div class="invalid-feedback">
                    <?php echo isset($errors['course']) ? htmlspecialchars($errors['course']) : ''; ?>
                </div>
            </div>
            <div class="form-group">
                <label for="enrollment_date" class="mb-2 mt-2">Select Enrollment Date</label>
                <input type="date" name="enrollment_date" value="<?php echo htmlspecialchars($enrollment_date); ?>"
                    class="form-control <?php echo isset($errors['enrollment_date']) || isset($errors['exists']) ? 'is-invalid' : ''; ?>"
                    required>
                <div class="invalid-feedback">
                    <?php
                    echo ($errors['enrollment_date']);
                    echo ($errors['exists']);
                    ?>
                </div>
            </div>
            <p class="mt-4">Don't want to add an enrollment? <a href="enrollment.php" class="backclass">Go Back</a></p>

            <div class="form-group text-center">
                <input type="submit" name="submit" class="btn btn-success text-center mb-3 mt-3" value="Submit">

            </div>
        </form>
    </div>
</div>

<?php include("footer.php"); ?>

