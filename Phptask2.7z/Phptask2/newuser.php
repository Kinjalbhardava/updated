<style>
    h2{
        color: #337ab7;
    }
    .backclass{
        text-decoration: none;
        color: #337ab7;
    }
</style>
<?php
ob_start();
session_start();

if (isset($_SESSION["admin_email"])) {
    include("conn.php");
    include("header.php");

    $name = '';
    $email = '';
    $phone = '';
    $id = null;
    $nameError = '';
    $emailError = '';
    $phoneError = '';
    $existsError = '';
    $valid_phone_length = 10;

    // Fetch user data if ID is provided
    if (isset($_GET['id'])) {
        $id = (int) $_GET['id'];
        $stmt = $con->prepare("SELECT name, email, phone FROM user WHERE id = ?");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($row = $result->fetch_assoc()) {
            $name = $row['name'];
            $email = $row['email'];
            $phone = $row['phone'];
        }
    }

    // Handle form submission

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $name = trim($_POST['name']);
        $email = ($_POST['email']);
        $phone = trim($_POST['phone']);

        // Name Validation
        if (empty($name)) {
            $nameError = "Please enter your name.";
        } elseif (!preg_match('/^[a-zA-Z\s]+$/', $name)) {
            $nameError = "Please enter a valid name.";
        }

        // Email Validation
        if (empty($email)) {
            $emailError = "Please enter your email.";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $emailError = "Please enter a valid email.";
        }

        // Phone Validation
        if (empty($phone)) {
            $phoneError = "Please enter your phone number.";
        } elseif (strlen($phone) !== $valid_phone_length || !preg_match('/^\d+$/', $phone)) {
            $phoneError = "Phone number must contain only numbers and be exactly $valid_phone_length digits long.";
        }

        // Proceed only if no validation errors
        if (empty($nameError) && empty($emailError) && empty($phoneError)) {
            // Check for existing email
            if ($id) {
                $stmt = $con->prepare("SELECT * FROM user WHERE email = ? AND id != ?");
                $stmt->bind_param("si", $email, $id);
            } else {
                $stmt = $con->prepare("SELECT * FROM user WHERE email = ?");
                $stmt->bind_param('s', $email);
            }

            if ($stmt->execute()) {
                $result = $stmt->get_result();
                if ($result->num_rows > 0) {
                    $emailError = "This email is already registered. Please use a different one.";
                } else {
                    if ($id) {
                        $stmt = $con->prepare("UPDATE user SET name = ?, email = ?, phone = ? WHERE id = ?");
                        $stmt->bind_param('sssi', $name, $email, $phone, $id);
                    } else {
                        $stmt = $con->prepare("INSERT INTO user (name, email, phone) VALUES (?, ?, ?)");
                        $stmt->bind_param('sss', $name, $email, $phone);
                    }

                    if ($stmt->execute()) {
                        error_log("Redirecting to users.php with status: " . ($id ? 'update' : 'success'));
                        header('Location: users.php?status=' . ($id ? 'update' : 'success'));

                        exit();
                    } else {
                        error_log("Database error: " . $stmt->error);
                        $existsError = "An error occurred. Please try again.";
                    }
                }
            } else {
                error_log("Database error: " . $stmt->error);
            }
            $stmt->close();
        }
    }
?>

<form method="POST">
    <div id="page-wrapper">
        <div class="row">
            <div class="col-lg-12" style="margin-top:40px;">
                <h2 class="form-header text-center"><?php echo ($id) ? 'Update User' : 'Add User'; ?></h2>
                <div class="form-group">
                    <label for="name" class="mb-2">Name</label>
                    <input type="text" name="name" value="<?php echo htmlspecialchars($name, ENT_QUOTES, 'UTF-8'); ?>"
                        placeholder="Please enter your name" class="form-control" id="name">
                    <div class="text-danger"><?php echo $nameError; ?></div>
                </div>

                <div class="form-group">
                    <label for="email" class="mb-2 mt-2">Email</label>
                    <input type="text" name="email"
                        value="<?php echo htmlspecialchars($email, ENT_QUOTES, 'UTF-8'); ?>"
                        placeholder="Please enter your email address" class="form-control" id="email">
                    <div class="text-danger"><?php echo $emailError; ?></div>
                </div>

                <div class="form-group">
                    <label for="phone" class="mt-2">Phone</label>
                    <input name="phone" value="<?php echo htmlspecialchars($phone, ENT_QUOTES, 'UTF-8'); ?>"
                        placeholder="Please enter your phone number" class="form-control mb-2 mt-2" type="text"
                        id="phone">
                    <div class="text-danger"><?php echo $phoneError; ?></div>
                </div>

                <p class="mt-4">Don't want to add user? <a href="users.php" class="backclass">Go Back</a></p>
                <div class="form-group text-center">
                    <button type="submit" class="btn btn-success">Submit</button>
                </div>

                <div class="text-danger"><?php echo $existsError; ?></div>
            </div>
        </div>
    </div>
</form>

<?php include("footer.php");
} else {
    // Redirect to login if not authenticated
    header("Location: login.php");
    exit();
}
?>
