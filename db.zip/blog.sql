-- phpMyAdmin SQL Dump
-- version 5.1.1deb5ubuntu1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Feb 11, 2025 at 07:30 AM
-- Server version: 8.0.41-0ubuntu0.22.04.1
-- PHP Version: 8.2.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blog`
--

-- --------------------------------------------------------

--
-- Table structure for table `blogs`
--

CREATE TABLE `blogs` (
  `id` int NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `content` text COLLATE utf8mb4_general_ci NOT NULL,
  `author` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  `image_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `blogs`
--

INSERT INTO `blogs` (`id`, `title`, `content`, `author`, `created_at`, `updated_at`, `image_name`) VALUES
(6, 'Mistakes to Avoid in Stock Market Investing', '<p>New and experienced investors alike can make mistakes in the stock market. This post highlights five common errors to avoid to increase your chances of success in the market.</p>', 'James Roberts', '2024-12-18 18:30:00', '2024-12-30 06:16:35', '[\"1735559214_42fa608ee492ef3dfe46.png\"]'),
(105, 'The Rise of CodeIgniter: Why Developers Love It', '<p>Explore how AI is transforming industries, from healthcare to transportation, and what it means for the future of humanity.\"</p>', 'Sarah Johnson', '2024-12-26 06:38:01', '2024-12-28 08:34:10', '[]'),
(117, 'The Art of Minimalist Living', '<p>In today’s fast-paced world, minimalist living offers a refreshing perspective on life. By focusing on what truly matters and <strong>decluttering</strong> both our physical and mental spaces, we can find peace and fulfillment.</p>', 'Jane Doe', '2024-12-27 05:06:54', '2024-12-27 05:06:54', '[\"1735295814_9208270202e917c840f6.mp3\"]'),
(119, '10 Tips for a Perfect Morning Routine', '<p>Starting your day right can make all the difference. Here are 10 tips to create a morning routine that sets you up for success:</p><ol><li>Wake up at a consistent time each day.</li><li>Hydrate with a glass of water immediately.</li><li>Spend 5-10 minutes meditating or practicing mindfulness.</li><li>Get moving—try yoga, a walk, or a workout.</li><li>Eat a nutritious breakfast to fuel your body.</li><li>Review your goals or to-do list for the day.</li><li>Spend a few minutes reading something inspirational.</li><li>Avoid checking your phone first thing in the morning.</li><li>Take time to groom and dress for the day.</li><li>Start with a task you’re excited about to build momentum.</li></ol>', 'Sarah Lee', '2024-12-27 05:08:24', '2024-12-27 05:08:24', '[]'),
(121, 'The Rise of Artificial Intelligence in Everyday Life', '<p>Artificial Intelligence (AI) is no longer a concept of the future—it’s here, transforming the way we live. From voice assistants like Siri and Alexa to recommendation algorithms on Netflix and Spotify, AI is seamlessly integrated into our daily routines.</p>', 'David Carter', '2024-12-27 05:10:01', '2024-12-28 03:36:49', '[]'),
(174, 'Wealth and health', '<p>Wealth and health Wealth and health</p>', 'Sarah Thompson', '2024-12-30 01:12:43', '2024-12-30 05:11:12', '[]'),
(187, 'hello codeigniter 4', '<p>SSSSAAAAAAAAAAA</p>', 'Alex Brown', '2024-12-30 06:26:01', '2024-12-30 08:43:01', '[\"1735567981_8941e35ab6b2a99c210d.pdf\"]'),
(201, '=\"google.com\" efrf bfb rf v', '<p>&lt;p&gt;sedcccccccccccccc&lt;/p&gt;</p>', 'cws', '2024-12-31 05:07:39', '2024-12-31 08:30:21', '[]'),
(208, '<a href=\"apple.com\"> apple </a> <a href=\"apple.com\"> apple </a>', '<p>eddddddddd</p>', 'Emily Collins', '2025-01-01 04:17:27', '2025-01-02 05:07:05', '[\"1735725208_8170ee96c0baf69f86b9.png\",\"1735725217_e97f3960cd0f5b298bf8.png\",\"1735725225_5334bc2d7f8d15effd36.jpeg\",\"1735725237_5ad630a15ba2c94df864.png\",\"1735731153_3740212a89845fd020a2.pdf\",\"1735731330_cb72e1f0df1b2d4589d7.mp3\"]'),
(209, 'sw wdaz  ds', '<p>dccccccccccccc</p>', 'sdc', '2025-01-01 04:36:28', '2025-01-01 04:39:12', '[\"1735725988_334538a677c347393809.pdf\",\"1735725988_f2f5d7605a6cd7a02999.png\",\"1735725988_55b9cab9b9929e50d380.mp3\",\"1735725988_381ef2e7fa6ef84577c7.pdf\",\"1735725988_72f366af70ceb70667ea.png\",\"1735726069_2ac87e87f30dea5fc33c.png\"]'),
(210, '\"\" \"\" \"\" \"\"', '<p>dcccc</p>', 'cddddd', '2025-01-01 04:40:23', '2025-01-01 05:41:00', '[]'),
(211, 'sd xxxxcdscx c cxad', '<p>sxsdddddddddddddc</p>', '<a href=\"/blog_app/ class=\'btn btn-primary\' \">Submit</a>', '2025-01-01 04:42:45', '2025-01-01 05:41:45', '[\"1735727485_1c37491c4400fdbde39a.pdf\",\"1735727485_b311719549d7ebb4f9c7.pdf\",\"1735727485_4ffd1fb8eb7e34e4afb9.png\",\"1735727485_07a2bdf8a454faa14bd0.mp3\",\"1735727496_31bdb4038dfdf82c5ff1.pdf\",\"1735727496_b65872ee6fbe32a9ecf5.png\"]'),
(213, 'bj hjb  v', '<p>ruuuuuuuuuuuuuuy</p>', 'Michael Green', '2025-01-01 05:47:37', '2025-01-02 07:22:09', '[\"1735814410_de22533832b91daa5ea3.mp3\",\"1735814437_e2819c5cfa9ebaf5f298.png\",\"1735814689_2d361c593eaa620eddfb.png\",\"1735822311_8e03782678f9b5de68a1.mp3\",\"1735822329_222c9c293c281631d3bb.png\"]'),
(214, 'This is about Business', '<p>business of 2024</p>', 'Michael Green', '2025-01-02 05:16:12', '2025-01-02 06:28:07', '[\"1735814772_ae2ddb67fb02ac93951b.mp3\",\"1735814772_8ec53a613b8f0992b435.pdf\",\"1735814772_360512d6edc661949101.pdf\",\"1735814772_7fc4503f9c71637f4115.mp3\",\"1735814772_9f210a053fc83aa70800.png\",\"1735814780_500bd356c12cd9f72467.mp3\"]'),
(215, 'fweg rk n rge', '<p>rgxd</p>', 'John Smith', '2025-01-02 07:45:33', '2025-01-03 22:48:48', '[\"1735823733_99c9e59ffc3213092132.mp3\",\"1735823733_ec4400c3ad19ddd07045.png\",\"1735823733_df7f001555d871fae5a4.png\",\"1735823733_f8bb4d5cdd8469bf5d16.mp3\",\"1735823733_de6d8d68ef45040658f4.pdf\",\"1735823774_1f3cd9d3fe37d96f54df.png\"]');

-- --------------------------------------------------------

--
-- Table structure for table `blog_img`
--

CREATE TABLE `blog_img` (
  `id` int NOT NULL,
  `blog_id` int NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `uploaded_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` bigint UNSIGNED NOT NULL,
  `version` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `class` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `group` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `namespace` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `time` int NOT NULL,
  `batch` int UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES
(1, '2024-12-19-061156', 'App\\Database\\Migrations\\Blogs', 'default', 'App', 1734588794, 1),
(2, '2024-12-26-050628', 'App\\Database\\Migrations\\AddColumnsToBlog', 'default', 'App', 1735189615, 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blogs`
--
ALTER TABLE `blogs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blog_img`
--
ALTER TABLE `blog_img`
  ADD PRIMARY KEY (`id`),
  ADD KEY `blog_id` (`blog_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blogs`
--
ALTER TABLE `blogs`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=216;

--
-- AUTO_INCREMENT for table `blog_img`
--
ALTER TABLE `blog_img`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `blog_img`
--
ALTER TABLE `blog_img`
  ADD CONSTRAINT `blog_img_ibfk_1` FOREIGN KEY (`blog_id`) REFERENCES `blogs` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
